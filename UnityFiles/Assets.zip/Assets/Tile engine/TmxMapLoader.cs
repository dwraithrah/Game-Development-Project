﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Xml.Linq;
using System.IO;
using System.Text;

public struct MapInfo {
  public ushort[][] layers;
  public int width;
  public int height;
  public int tilesetId;
  public int musicId;
}

// This class loads .tmx files (created with Tiled) for use in the game.
// This supports only a subset of the .tmx format:
//  - Only uncompressed base64-encoded maps
//  - Tile indexes are limited to 16 bits
//  - We expect custom properties "tileset" and "music", both ints.

public class TmxMapLoader {
  public static MapInfo LoadMap(string path) {
    TextReader reader;
    try {
      reader = File.OpenText(path);
    } catch(IOException e) {
      UnityEngine.Debug.LogError("Failed to load map: " + path + "\n" + e.Message);
      return new MapInfo();
    }
    XElement map = XDocument.Load(reader, LoadOptions.None).Element("map");
    reader.Close();
    int gtid = (int) map.Element("tileset").Attribute("firstgid");

    // Get tileset and music numbers
    IEnumerable<XElement> properties = map.Element("properties").Elements("property");
    int tileset = (int) properties.First(e => e.Attribute("name").Value == "tileset").Attribute("value");
    int music = (int) properties.First(e => e.Attribute("name").Value == "music").Attribute("value");
    
    // Get the width and height of this tile layer
    int width = (int) map.Attribute("width");
    int height = (int) map.Attribute("height");

    // Get tilemap data
    List<XElement> layers = new List<XElement>(map.Elements("layer"));
    int nLayers = layers.Count;
    ushort[][] layerData = new ushort[nLayers][];
    int layerNo = 0;
    foreach(XElement layer in layers) {
      XElement data = layer.Element("data");
      ushort[] array = layerData[layerNo] = new ushort[width * height];

      // Decode the Base64-encoded tilemap data
      Base64Decode(array, data.Value, gtid);

      // Tiles are stored in the .tmx file using left-handed coords (positive y = down), 
      // but Unity uses a right-handed system (positive y = up).
      // Flip the tilemap vertically to account for this
      for(int r = 0; r < height / 2; r++) {
        int o1 = r * width, 
            o2 = (height - r - 1) * width;
        for(int c = 0; c < width; c++) {
          ushort x = array[o1+c];
          array[o1+c] = array[o2+c];
          array[o2+c] = x;
        }
      }
      layerNo++;
    }

    UnityEngine.Debug.Log("Map loaded: " + path);

    MapInfo mi = new MapInfo();
    mi.layers = layerData;
    mi.width = width;
    mi.height = height;
    mi.tilesetId = tileset;
    mi.musicId = music;
    return mi;
  }

  private static void Base64Decode(ushort[] dest, string src, int gtid) {
    UnityEngine.Debug.Log("Tilemap layer: " + src);
    byte[] bytes = System.Convert.FromBase64String(src);
    // interpret the bytes as 32-bit ints
    // (we convert to ushorts, so only keep the lower 16 bits)
    for(int i = 0, j = 0; i < bytes.Length; i += 4, j++) {
      int t = (bytes[i]) + (bytes[i+1] << 8) + (bytes[i+2] << 16) + (bytes[i+3] << 24);
      dest[j] = (ushort) (t - gtid);
    }
  }
}
