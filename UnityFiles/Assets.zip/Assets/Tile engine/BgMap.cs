﻿using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;

/** Represents a large scrollable tilemap which can be rendered to a BgLayer.
 * 
 */
public class BgMap {
  public int tileset; // tileset used by this map

  public int width;   // dimensions of map
  public int height;
  public int pxWidth { get { return width * 8; } }    // dimensions of map, in pixels
  public int pxHeight { get { return height * 8; } }

  // Map data array
  public ushort[] map;     // map data
  public ushort borderTile; // tile used to fill in out-of-bounds areas, if useBorderTile == true
  public BgLayer bg;  // BG layer used for rendering this map

  public Vector2 scroll;      // Scroll coordinates of this map
  private Vector2 prevScroll; // Previous scroll coordinates

  // Redraw flag, set this to redraw all visible tiles on the next frame
  public bool redraw;

  // Whether the edges of the map are drawn clear (false)
  // or filled with the border tile (true)
  public bool useBorderTile;

  public BgMap() {}
  public BgMap(BgLayer bg) {this.bg = bg;}

  public void Init(MapInfo mapInfo, int layer = 0) {
    if(mapInfo.layers != null && layer < mapInfo.layers.Length)
      map = mapInfo.layers[layer];
    width = mapInfo.width;
    height = mapInfo.height;
    bg.Tileset = tileset = mapInfo.tilesetId;
    redraw = true;
  }

  // Initialize an empty tilemap with the given tileset and dimensions.
  public void InitEmpty(int ts, int w, int h) {
    tileset = bg.Tileset = ts;
    width   = w;
    height  = h;
    map = new ushort[width * height];
    scroll = prevScroll = new Vector2();
  }

  // Returns the tile ID at the given position.
  public ushort this[int x, int y] {
    get { 
        if(x >= 0 && y >= 0 && x < width && y < height)
          return map[y*width+x];
        else
          return 0;
    }
    set {
      if(x >= 0 && y >= 0 && x < width && y < height)
        map[y*width+x] = value;
    }
  }

  // Draws exposed tiles in the tilemap
  // (sx, sy): source tile coordinates in level
  // (dx, dy): dest tile coordinates in BG map
  // (w, h): dimensions of rectangle 
  private void drawTilesFromMap(int sx, int sy, int w, int h) {
     for(int j = 0, y = sy; j < h; j++, y++) {
       if(y >= 0 && y < height) {
         int offset = y * width + ((sx < 0) ? 0 : sx);
         for(int i = 0, x = sx; i < w; i++, x++) {
           if(x >= 0 && x < width)
             bg.SetTile(x, y, map[offset++]);
           else if(useBorderTile)
             bg.SetTile(x, y, borderTile);
           else
             bg.ClearTile(x, y);
         }
       }
       else if(useBorderTile)
         bg.Fill(sx, y, w, 1, borderTile); 
       else
         bg.ClearTiles(sx, y, w, 1);
     }
  }

  // Update routine.
  public void FixedUpdate() {
    // find the coordinates of the scroll seam 
    int tx = ((int) scroll.x >> 3), // tile containing bottom left corner of camera rect
        ty = ((int) scroll.y >> 3);
    if(redraw) {
      drawTilesFromMap(tx, ty, 33, 31);
      redraw = false;
    }
    if(prevScroll != scroll) {
      int dtx = tx - ((int) prevScroll.x >> 3), // number of tiles we've scrolled
          dty = ty - ((int) prevScroll.y >> 3);
      int bx = tx, // actual bottom-left corner of the seam
          by = ty; 
      // which edges are we drawing?
      if(dtx < 0) { // left
        bx = tx - dtx - 1; 
        dtx = -dtx + 1;
      }
      else if(dtx > 0) // right
        bx = tx + 32;
      
      if(dty < 0) { // down
        by = ty - dty - 1;
        dty = -dty + 1;
      }
      else if(dty > 0) // up
        by = ty + 30;

      // now it's time to actually draw the tiles
      // draw corner
      if(dtx > 0 && dty > 0)
        drawTilesFromMap(bx, by, dtx, dty);
      // draw vertical edge
      if(dtx > 0)
        drawTilesFromMap(bx, ty, dtx, 31);
      // draw horizontal edge
      if(dty > 0)
        drawTilesFromMap(tx, by, 33, dty);
    }
    // update BG scroll coords   
    prevScroll = scroll;
    bg.ScrollX = (int) scroll.x;
    bg.ScrollY = (int) scroll.y;
  }

}
