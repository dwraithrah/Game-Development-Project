﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public struct RoomId {
  public ushort area, room; 
}

public class BackgroundManager: MonoBehaviour {

  private BgLayer fore, mid, back;
  private Camera camera;
  public BgMap[] layers;
  private byte[] foregroundTileCollision;

  public MapInfo mapInfo;
  public GameObject bgLayerPrototype;
  public Vector2 scroll;
  public ushort areaId, roomId;

  public void Awake() {
    // Turn off the camera so user doesn't see stuff being loaded
    // (we have to save in a var, since Camera.main becomes null when we disable)
    camera = Camera.main;
    camera.enabled = false;

    // Create the BG objects as children of the camera
    fore = Instantiate(bgLayerPrototype, camera.transform).GetComponent<BgLayer>();
    mid = Instantiate(bgLayerPrototype, camera.transform).GetComponent<BgLayer>();
    back = Instantiate(bgLayerPrototype, camera.transform).GetComponent<BgLayer>();
    
    // boring initialization code
    fore.Init();
    mid.Init();
    back.Init();
    fore.Tileset = mid.Tileset = back.Tileset = mapInfo.tilesetId;
    fore.z = 100;
    mid.z = 200;
    back.z = 300;
    fore.ClearTiles(0, 0, 64, 64);
    mid.ClearTiles(0, 0, 64, 64);
    back.ClearTiles(0, 0, 64, 64);

    layers = new BgMap[3];
    layers[0] = new BgMap(back);
    layers[1] = new BgMap(mid);
    layers[2] = new BgMap(fore);
    foregroundTileCollision = TilesetManager.GetTileCollision(layers[2].tileset);

    // Load the room file
    string roomPath = Application.streamingAssetsPath + "/maps/"+areaId+"/"+roomId+".tmx";
    mapInfo = TmxMapLoader.LoadMap(roomPath);

    // Point the map layers to the loaded map data
    for(int i = 0; i < 3; i++) {
      layers[i].Init(mapInfo, i);
    }

    // initial scroll update
    UpdateScroll();

    // Re-enable camera
    camera.orthographic = true;
    camera.orthographicSize = 15;
    camera.enabled = true;
  }

  private void UpdateScroll() {
    // convert scroll value from tile to pixel space
    layers[0].scroll = layers[1].scroll = layers[2].scroll = scroll * 8.0f;
    // move camera
    camera.transform.localPosition = new Vector3(scroll.x + 16, scroll.y + 15, -20);
  }

  public void FixedUpdate() {
    UpdateScroll();
    layers[0].FixedUpdate();
    layers[1].FixedUpdate();
    layers[2].FixedUpdate();
  }

  public byte GetTileCollision(int x, int y) {
    ushort tile = layers[2][x, y];
    if(tile == 0xFFFF) return 0;
    else return foregroundTileCollision[tile];
  }

} 
