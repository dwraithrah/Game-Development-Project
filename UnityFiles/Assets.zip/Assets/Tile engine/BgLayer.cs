﻿using System;
using UnityEngine;

/** 
 * Represents a tiled background layer.
 * 
 * A BgLayer manages a texture into which 8x8 tiles can be drawn, and a Unity sprite object using
 * that texture.
 * 
 * The background texture is 512x512 pixels, or 64x64 tiles.
 * 
 * Important limitation: This is not a true tilemap, but rather a set of drawing routines which
 * simulate a tilemap. We do not store tilemap data for dynamic rendering; instead the methods of this class
 * copy pixels directly from the tileset into a pixel buffer. It thus does not support dynamic things which 
 * require modifying the tileset data (such as tile animations).
 * 
 * This is also the reason for separate SetTile and ClearTile methods.
 */

public class BgLayer: MonoBehaviour {
  private Color32[] tileset;                    // Tileset image data and id, returned by TilesetManager
  private int currentTilesetId = -1;

  public int Tileset {
    get {return currentTilesetId;}
    set {
      currentTilesetId = value;
      tileset = TilesetManager.GetTileset(currentTilesetId);
      lastTile = -1; // invalidate last tile index
    }
  }

  // Z coordinate of this BG
  public float z;
  // Scroll coordinates of this BG 
  public int ScrollX {get; set;}
  public int ScrollY {get; set; }
  // Coarse tile coordinates, read only
  public int TileX {get {return (ScrollX >> 3) & 63;}}
  public int TileY {get {return (ScrollY >> 3) & 63;}}

  private Color32[] tilebuf = new Color32[64];  // Temporary buffer used when drawing tiles
  private Texture2D bgbuf;                      // Background texture, this is what gets put on screen
  private bool updateFlag = false;              // Set when a tile has been modified
  private int lastTile = -1;                    // The last used tile index

  // Call this before doing anything else!!!
  public void Init() {
    // create the texture
    bgbuf = new Texture2D(512, 512, TextureFormat.ARGB32, false, false);
    bgbuf.wrapMode = TextureWrapMode.Repeat;
    bgbuf.filterMode = FilterMode.Point;
    // and the sprite
    SpriteRenderer sr = gameObject.GetComponent<SpriteRenderer>();
    sr.sprite = Sprite.Create(bgbuf, new Rect(0f, 0f, 512f, 512f), new Vector2(0f, 0f), 8f, 0, SpriteMeshType.FullRect);
    sr.size = new Vector2(128, 128); 
  }

  // Draws a single tile at the given coordinates.
  public void SetTile(int x, int y, ushort index) {
    // compute destination coordinates in tilemap
    x = (x & 63) << 3;
    y = (y & 63) << 3;
    // source offset in tileset array (TilesetManager flipped it already)
    int j = ((index & 0x001F) << 3) + ((index & 0x03E0) << 6);
    // copy 8x8 pixels into temporary buffer
    if(index != lastTile) {
      for(int i = 56; i >= 0; i -= 8) {
        tilebuf[i] = tileset[j++];
        tilebuf[i+1] = tileset[j++];
        tilebuf[i+2] = tileset[j++];
        tilebuf[i+3] = tileset[j++];
        tilebuf[i+4] = tileset[j++];
        tilebuf[i+5] = tileset[j++];
        tilebuf[i+6] = tileset[j++];
        tilebuf[i+7] = tileset[j++];
        j += 248; // next row
      }
      lastTile = index;
    }
    // draw pixels to texture and set update flag
    bgbuf.SetPixels32(x, y, 8, 8, tilebuf, 0);
    updateFlag = true;

  }

  // Clears the tile at the given coordinates.
  public void ClearTile(int x, int y) {
    // compute destination coordinates in tilemap
    x = (x & 63) << 3;
    y = (y & 63) << 3;
    if(lastTile != -1) {
      Array.Clear(tilebuf, 0, 64);
      lastTile = -1;
    }
    bgbuf.SetPixels32(x, y, 8, 8, tilebuf, 0);
    updateFlag = true;
  }

  // Clears a rectangular region.
  public void ClearTiles(int x, int y, int w, int h) {
    for(int i = 0; i < h; i++)
      for(int j = 0; j < w; j++)
        ClearTile(x+i, y+j);
  }

  // Draws a rectangular block of tiles from an array.
  // The dimension of the array must be at least (w * h).
  public void SetTiles(int x, int y, int w, int h, ushort[] tiles) {
    int k = 0;
    for(int j=0; j<h; j++) {
      for(int i=0; i<w; i++)
        SetTile(x+i, y+j, tiles[k++]);
    }
  }

  // Fills a rectangular region with a single tile.
  public void Fill(int x, int y, int w, int h, ushort index) {
    for(int i = 0; i < h; i++)
      for(int j = 0; j < w; j++)
        SetTile(x+i, y+j, index); 
  }

  public void FixedUpdate() {
    // If texture was modified, commit changes to GPU
    if(updateFlag) {
      bgbuf.Apply();
      updateFlag = false;
    }

    // apply scrolling
    transform.localPosition = new Vector3(-(float) ((ScrollX & 511) + 128) * 0.125f, -(float) ((ScrollY & 511) + 120) * 0.125f, z);
  }
}
