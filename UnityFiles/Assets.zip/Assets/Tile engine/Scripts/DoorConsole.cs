﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorConsole : MonoBehaviour {

    public bool consoleTriggered = false;
    private bool hasActivatedConsole = false;
    public Transform OpenDoor;
    private GameObject ExitDoor;
    public Vector3 doorSpawn;

    // Use this for initialization
    void Start () {

        ExitDoor = GameObject.FindGameObjectWithTag("ExitDoor");
    }
	
	// Update is called once per frame
	void Update () {
		
        if(consoleTriggered && Input.GetKeyDown(KeyCode.E) && !hasActivatedConsole)
        {
            Instantiate(OpenDoor, doorSpawn, Quaternion.identity);
            hasActivatedConsole = true;
            Destroy(ExitDoor);
        }
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        //if player collider runs into coin collider, destroy coin
        if (other.gameObject.CompareTag("Player"))
        {

            consoleTriggered = true;

        }

    }
}
