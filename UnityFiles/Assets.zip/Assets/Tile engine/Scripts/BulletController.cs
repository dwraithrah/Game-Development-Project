﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour {


	private string direction;
	public Vector3 velocity;
	// Use this for initialization
	void Start () {
		velocity = new Vector3 (0.33f, 0f);
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (direction == "right") {
			transform.position += velocity;
		} 
		else {
			transform.position -= velocity;
		}
	}

	public void SetRight(bool right)
	{
		if (right) {
			direction = "right";
		} 
		else {
			direction = "left";
		}
	}

	void OnTriggerEnter2D (Collider2D coll)
	{

	}

	void OnCollisionEnter2D (Collision2D coll)
	{
		if (coll.gameObject.tag == "Enemy") {
			//Destroy (coll.gameObject);
		}

		if (coll.gameObject.tag != "Player") {
			Destroy (gameObject);
		}
	}

	void OnCollisionStay2D(Collision2D coll)
	{
		if (coll.gameObject.tag == "Enemy") {
			//Destroy (coll.gameObject);
		}
		
		if (coll.gameObject.tag != "Player") {
			Destroy (gameObject);
		}
	}
}
