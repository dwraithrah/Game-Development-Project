﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WarningTrigger : MonoBehaviour {

    public bool warningGiven = false;

    private GameObject dialogManager;
    private DialogManager dM;

    // Use this for initialization
    void Start () {
        dialogManager = GameObject.Find("Dialogue Manager");
        dM = (DialogManager)dialogManager.GetComponent(typeof(DialogManager));
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Player" && !warningGiven)
        {
            warningGiven = true;
            dM.WarningScript();
            
        }
    }
}
