﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//There's a tutorial for switching scenes and keeping objects for those scenes.
//https://www.youtube.com/watch?annotation_id=annotation_3968548225&feature=iv&src_vid=S9h_iu4Zx5I&v=i2W5O5qxCuo
//Highly recommend everyone looks at this.

public class DataHolderController : MonoBehaviour {

    public static int playerHealth;
    public static int sceneIndex;
    public static DataHolderController anymanager;

    bool gameStart;  //this is to ensure that the initial load is done only once
	public static bool powerJump;
	public static bool doubleJump;
	public static bool meleeUpgrade;
	public static bool gunUpgrade;

    void Awake()
    {
        //if (!gameStart)
        //{
            //initial values at game start
            playerHealth = 5;
			sceneIndex =  SceneManager.GetActiveScene().buildIndex;
            Debug.Log("Active Scene is:");
            Debug.Log(sceneIndex);

            anymanager = this;

            //load next scene (start of game) while keeping this object, the data holder.
            //Async means scene is loaded in background
            //SceneManager.LoadSceneAsync(sceneIndex, LoadSceneMode.Additive);

            gameStart = true;
			doubleJump = powerJump = meleeUpgrade = gunUpgrade = false;
        // sceneIndex++;
        // Debug.Log(sceneIndex);
        // SceneManager.LoadSceneAsync(sceneIndex, LoadSceneMode.Additive);


        //}

        
    }
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {

        if(playerHealth <= 0)
        {
            StartCoroutine(ReloadScene());
			playerHealth = 5;
        }
	}

    IEnumerator ReloadScene()
    {
        Debug.Log("Loading Scene Via Data holder");
        SceneManager.LoadScene(2, LoadSceneMode.Single);
        yield return null;
        Debug.Log("Unloading Scene via data holder");
        Debug.Log(sceneIndex);
        SceneManager.UnloadSceneAsync(DataHolderController.sceneIndex);
        

    }

    //function to unload scenes
    public void UnloadScene(int scene)
    {
        StartCoroutine(Unload(scene));
    }

    IEnumerator Unload(int scene)
    {

        SceneManager.LoadSceneAsync(scene, LoadSceneMode.Additive);
        yield return null;
        //SceneManager.UnloadScene(scene-1);
    }
}
