﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {
    public BackgroundManager bgman;

    //the player transform. Can be modified in inspector. 
    public Transform player;

    //can set this to whatever value you want in inspector as you decide where exactly to place the camera. 
    //Note, in the update code the y-axis is turned off so camera will not change vertically. 
    public Vector3 cameraOffset;

    // Use this for initialization
    void Start () {
      Update();
    }

    private void Scroll(Vector2 n) {
      float w = bgman.mapInfo.width;
      float h = bgman.mapInfo.height;

      if(n.x < 0) n.x = 0;
      else if(n.x + 32 > w) n.x = w - 32;

      if(n.y < 0) n.y = 0;
      else if(n.y + 30 > h) n.y = h - 30;

      bgman.scroll = n;
    }
	
    // Update is called once per frame
    void Update () {
    //the camera will follow the player with a certain offset.  Y offset is turned off so camera only follows along x-axis.
      if(bgman)
        Scroll(new Vector2(player.position.x + cameraOffset.x, player.position.y + cameraOffset.y));
      else // for compatibility with levels that don't use BackgroundManager
        transform.localPosition = new Vector3(player.position.x + cameraOffset.x, player.position.y + cameraOffset.y, cameraOffset.z);
    }
}
