﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {


    //needed to move enemy back and forth
    public enum OccilationFuntion { Sine, Cosine }

 	Vector2 startingPosition;
    bool dirLeft;

    public float moveSpeed = 1.0f;
	private bool stunned;
	private IEnumerator stunWait;
	private Animator animator;
	private SpriteRenderer spriteRenderer;
	public BoxCollider2D worldCollider;
	public BoxCollider2D triggerCollider;

    private GameObject soundEffects;
    private SoundEffects SE;

    private void Awake()
    {
        soundEffects = GameObject.Find("SoundEffectsController");
        SE = (SoundEffects)soundEffects.GetComponent(typeof(SoundEffects));
    }

    // Use this for initialization
    void Start () {
     
    	startingPosition = transform.position;
        dirLeft = true; //enemy starts moving left
		stunned = false;
  		animator = GetComponent<Animator>();
  		spriteRenderer = GetComponent<SpriteRenderer>();
  		animator.Play("CrawlerMove", -1, 0f);

  		//Physics2D.IgnoreCollision(worldCollider, GameObject.FindWithTag("Player").GetComponent<Collider2D>());
    }

    // Update is called once per frame
    void Update () {

    	Physics2D.IgnoreCollision(worldCollider, GameObject.FindWithTag("Player").GetComponent<Collider2D>());

		if (!stunned) {
			//script to make enemy move back and forth
			if (dirLeft) {//if headed left
				transform.Translate (-Vector2.right * moveSpeed * Time.deltaTime); //keep moving left
				spriteRenderer.flipX = true;
			} else { //if headed right
				transform.Translate (Vector2.right * moveSpeed * Time.deltaTime);
				spriteRenderer.flipX = false;
			}
		}
	}
		
	void OnCollisionStay2D(Collision2D other)
	{
		if (other.gameObject.tag == "Bullet") {
			Stun ();
		}
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
		if (collision.gameObject.tag == "Bullet") {
			Stun ();
		}

        if((collision.gameObject.tag != "Player") && (collision.gameObject.tag != "Enemy" && collision.gameObject.tag != "ground")) //if collide with anything other than player
        {
            dirLeft = !dirLeft; //if enemy runs into something not the player, change from false to true or vice versa
        }
    }

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.gameObject.tag == "PlayerMelee") {
            SE.EnemyDeath();
			gameObject.SetActive (false);
		}
	}

    private void Respawn()
    {
    	// Return the enemy to its starting position, and reset the direction it was initially facing
    	// Things like health, etc. can be reset here later
    	transform.position = startingPosition;
    	dirLeft = true;
    }

	public void Stun()
	{
		stunned = true;
		stunWait = StunWait ();
		StartCoroutine (stunWait);
	}

	IEnumerator StunWait()
	{
		yield return new WaitForSeconds (2);
		stunned = false;
	}
}
