﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelChanger : MonoBehaviour {

    public string levelToLoad;  //this is so you can just drag and drop the level to load in the inspector

    public bool loaded;  //used to load scene if not loaded

    private GameObject dataHolderController;
    private DataHolderController dH;


    // Use this for initialization
    void Start () {

       dataHolderController = GameObject.Find("DataHolder");
       dH = (DataHolderController)dataHolderController.GetComponent(typeof(DataHolderController));

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        //if player collider runs into door collider, the next scene will load
        if (other.gameObject.CompareTag("Player"))
        {

            if(!loaded)
            {
                //load next scene
                loaded = true;
                DataHolderController.sceneIndex++;
                StartCoroutine(ChangeScene());
                
            }

        }

    }

    IEnumerator ChangeScene()
    {
        Debug.Log("Scene to be loaded is:");
        Debug.Log(DataHolderController.sceneIndex);
        SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex+1, LoadSceneMode.Additive);
        SceneManager.MoveGameObjectToScene(GameObject.FindGameObjectWithTag("Data Holder"), SceneManager.GetSceneByBuildIndex(SceneManager.GetActiveScene().buildIndex + 1));
        SceneManager.MoveGameObjectToScene(GameObject.FindGameObjectWithTag("Canvas"), SceneManager.GetSceneByBuildIndex(SceneManager.GetActiveScene().buildIndex+1));
        SceneManager.MoveGameObjectToScene(GameObject.FindGameObjectWithTag("SoundController"), SceneManager.GetSceneByBuildIndex(SceneManager.GetActiveScene().buildIndex + 1));

        yield return null;
    }
}
