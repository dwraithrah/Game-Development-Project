﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpMeleeController : MonoBehaviour {

    private GameObject dialogManager;
    private DialogManager dM;

    // Use this for initialization
    void Start () {
        dialogManager = GameObject.Find("Dialogue Manager");
        dM = (DialogManager)dialogManager.GetComponent(typeof(DialogManager));
    }
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		//if player collider runs into coin collider, destroy coin
		if (other.gameObject.CompareTag("Player"))
		{
            //call script function that will pause game and briefly explain what all is going on
            dM.MeleeUpScript();

            DataHolderController.doubleJump = true;
            Destroy(gameObject);

        }

	}
}
