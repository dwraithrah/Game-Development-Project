﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CoinScript : MonoBehaviour
{

    private GameObject tutorialController;
    private TutorialController tC;

    // Use this for initialization
    void Start()
    {
        tutorialController = GameObject.Find("TutorialController");
        tC = (TutorialController)tutorialController.GetComponent(typeof(TutorialController));
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        //if player collider runs into coin collider, destroy coin
        if (other.gameObject.CompareTag("Player"))
        {

            tC.playerCanSword = true;
            Destroy(gameObject);
            
        }
            
    }
}