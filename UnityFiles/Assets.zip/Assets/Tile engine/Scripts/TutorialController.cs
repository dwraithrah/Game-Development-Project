﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TutorialController : MonoBehaviour {

    private Camera mainCamera;
    private GameObject player;
    private Transform playerPosition;
    private GameObject dialogManager;
    private DialogManager dM;
    private GameObject timerManager;
    private TimerController tC;
    public Transform EnemyTutorial;
    public Transform OpenDoor;
    public Transform Pinchsect;
    private float timer = 0.0f;
    private float endTime = 3.0f;


    //player triggers
    public bool playerCanMove = false;
    public bool playerCanJump = false;
    public bool playerCanShoot = false;
    public bool playerCanSword = false;
    public bool consoleTrigger = false;

    public bool canOpenDoor = true;

    //enemy triggers
    public bool enemyCanMove = false;

    private void Awake()
    {

        //we find our player object. Then we set our main camera to be centered over the player, then zoom in so tat only the first part of the level is visible.
        //Also the game is initially paused for starting tutorial dialogue.
        player = GameObject.FindGameObjectWithTag("Player");
        mainCamera = Camera.main;
        playerPosition = player.transform;
        mainCamera.enabled = true;    
    }

    // Use this for initialization
    void Start () {

        dialogManager = GameObject.Find("Dialogue Manager");
        dM = (DialogManager)dialogManager.GetComponent(typeof(DialogManager));
        timerManager = GameObject.Find("TimerController");
        tC = (TimerController)timerManager.GetComponent(typeof(TimerController));

	}

    void Update()
    {
        if (playerCanSword && consoleTrigger && Input.GetKeyDown(KeyCode.E) && canOpenDoor) 
        {
            Debug.Log("Starting Event");
            canOpenDoor = false;
            eventEleven();
        }
    }

    /*

  
    private void eventNine()
    {
        gamePause();
        string[] dialogue = new string[2];
        string[] name = new string[2];

        dialogue[0] = "(This clip here ought to fit. Perfect!  Now to go take care of that blobber.";
        dialogue[1] = "To attack an enemy with a vibroblade press the X button";

        name[0] = "Ianella";
        name[1] = "Tutorial";

        dM.dialogue = dialogue;
        dM.names = name;
        dM.ShowBox(dialogue[0], name[0]);
    }

    private void eventTen()
    {
        gamePause();
        string[] dialogue = new string[4];
        string[] name = new string[4];

        dialogue[0] = "Yes! I did it! Scratch one Blobby thing!";
        dialogue[1] = "Good job! Now search through that docking bay for anything valuable.";
        dialogue[2] = "Uh. Sure.  This area is a bit small but there might be more. I'll see if I can find a console and open a door out of here";
        dialogue[3] = "Find a computer console and hit the E button to activate it";

        name[0] = "Ianella";
        name[1] = "Captain Borst";
        name[2] = "Ianella";
        name[3] = "Tutorial";

        dM.dialogue = dialogue;
        dM.names = name;
        dM.ShowBox(dialogue[0], name[0]);
    }*/

    private void eventEleven()
    {
        Debug.Log("instantiating open door");
        Instantiate(OpenDoor, new Vector3(8.38f, -4.21f, 37.5211f), Quaternion.identity);
        Instantiate(Pinchsect, new Vector2(OpenDoor.position.x, OpenDoor.position.y), Quaternion.identity);
        Pinchsect.transform.SetParent(null);
    }
    


}
