﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttackControllerTutorial : MonoBehaviour {

    public Transform bullet;
    public Transform bulletUp;

    private Animator anim;
    private PlayerControllerTutorial player;
    private BoxCollider2D melee;
    private float lastAttacked;
    private Vector3 offset;
    private Vector3 upOffset;

    private GameObject soundEffects;
    private SoundEffects SE;


    //for tutorial
    private GameObject tutorialController;
    private TutorialController tC;

    // Use this for initialization
    void Start()
    {
        anim = GetComponent<Animator>();
        player = GetComponentInParent<PlayerControllerTutorial>();
        melee = GetComponent<BoxCollider2D>();
        offset = new Vector3(1.5f, 0.37f, 0);
        upOffset = new Vector3(0.2f, 2f, 0);
        lastAttacked = Time.time;
        //gameObject.SetActive (false);

        

        //for tutorial
        tutorialController = GameObject.Find("TutorialController");
        tC = (TutorialController)tutorialController.GetComponent(typeof(TutorialController));

        soundEffects = GameObject.Find("SoundEffectsController");
        SE = (SoundEffects)soundEffects.GetComponent(typeof(SoundEffects));
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Melee") && tC.playerCanSword)
        {
            melee.enabled = true;
            lastAttacked = Time.time;
        }
        else if (Input.GetButtonDown("Gun") && Time.time - lastAttacked >= 0.3f && tC.playerCanShoot)
        {
            SE.LaserSound();
            if (Input.GetButton("Up") && player.FacingRight())
            {
                Transform newBullet = Instantiate(bulletUp, player.transform.position + upOffset, Quaternion.identity) as Transform;
            }
            else if (Input.GetButton("Up"))
            {
                Vector3 upLeft = new Vector3(-upOffset.x, upOffset.y, upOffset.z);
                Transform newBullet = Instantiate(bulletUp, player.transform.position + upLeft, Quaternion.identity) as Transform;
            }
            else if (player.FacingRight())
            {
                Transform newBullet = Instantiate(bullet, player.transform.position + offset, Quaternion.identity) as Transform;
                BulletController newBulletController = newBullet.gameObject.GetComponent<BulletController>();
                newBulletController.SetRight(true);
            }
            else
            {
                Vector3 leftOffset = new Vector3(offset.x, -offset.y, offset.z);
                Transform newBullet = Instantiate(bullet, player.transform.position - leftOffset, Quaternion.identity) as Transform;
                BulletController newBulletController = newBullet.gameObject.GetComponent<BulletController>();
                newBulletController.SetRight(false);
            }
        }

        if (Time.time - lastAttacked >= 0.3f)
        {
            melee.enabled = false;
        }
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Enemy")
        {
            SE.EnemyDeath();
            Destroy(coll.gameObject);
        }
    }

    void OnCollisionStay2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Enemy")
        {
            SE.EnemyDeath();
            Destroy(coll.gameObject);
        }
    }
}
