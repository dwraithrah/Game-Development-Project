﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WarehouseCamera : MonoBehaviour
{


    //the player transform. Can be modified in inspector. 
    public Transform player;

    //can set this to whatever value you want in inspector as you decide where exactly to place the camera. 
    //Note, in the update code the y-axis is turned off so camera will not change vertically. 
    public Vector3 cameraOffset;

    public float MIN_X;
    public float MAX_X;
    public float MIN_Y;
    public float MAX_Y;

    // Use this for initialization
    void Start()
    {

    }



    // Update is called once per frame
    void Update()
    {

        transform.localPosition = new Vector3(Mathf.Clamp(player.position.x + cameraOffset.x, MIN_X, MAX_X), Mathf.Clamp(player.position.y + cameraOffset.y, MIN_Y, MAX_Y), cameraOffset.z);
        /*if (player.transform.position.x <= leftEdge)
        {
            transform.localPosition = new Vector3(this.transform.position.x, player.position.y + this.transform.position.y, cameraOffset.z);
        }
        else if(player.transform.position.y <= bottomEdge)
        {
            transform.localPosition = new Vector3(player.position.x + this.transform.position.x, this.transform.position.y, cameraOffset.z);
        }
        else
        {
            
        }
            
    }*/
    }
}
