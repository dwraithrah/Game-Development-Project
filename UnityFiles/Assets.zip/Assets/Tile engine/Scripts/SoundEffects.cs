﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundEffects : MonoBehaviour {

    private AudioSource audioSource;

    public  AudioClip laser;
    public  AudioClip enemyDeathSound;
    public  AudioClip sword;
    public  AudioClip scream;
    public  AudioClip jumpSound;
    public AudioClip birthSound;
    public AudioClip hopperJump;
    public AudioClip hopperLand;
    public AudioClip bossRoar;
    public AudioClip bossProjectile;

    // Use this for initialization
    void Start () {
        audioSource = GetComponent<AudioSource>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void LaserSound()
    {
        audioSource.PlayOneShot(laser, .7f);
    }

    public void SwordSound()
    {
        audioSource.PlayOneShot(sword, .7f);
    }

    public void PlayerScream()
    {
        audioSource.PlayOneShot(scream, .7f);
    }

    public void EnemyDeath()
    {
        audioSource.PlayOneShot(enemyDeathSound, .7f);
    }

    public void JumpSound()
    {
        audioSource.PlayOneShot(jumpSound, .7f);
    }

    public void BirthSound()
    {
        audioSource.PlayOneShot(birthSound, .7f);
    }

    public void HopperJump()
    {
        audioSource.PlayOneShot(hopperJump, .7f);
    }

    public void HopperLand()
    {
        audioSource.PlayOneShot(hopperLand, .7f);
    }

    public void BossRoar()
    {
        audioSource.PlayOneShot(bossRoar, 1f);
    }

    public void BossProjectile()
    {
        audioSource.PlayOneShot(bossProjectile, 1.5f);
    }
}
