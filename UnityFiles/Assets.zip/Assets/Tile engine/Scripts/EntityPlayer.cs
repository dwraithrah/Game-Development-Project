﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[Serializable] public struct PlayerInput {
  public bool left, right, down, jump;

  public void Poll() {
    left = Input.GetKey(leftKey);
    right = Input.GetKey(rightKey);
    down = Input.GetKey(downKey);
    jump = Input.GetKey(jumpKey);
  }

  public const KeyCode
    leftKey  = KeyCode.A, 
    rightKey = KeyCode.D, 
    downKey  = KeyCode.S, 
    jumpKey  = KeyCode.Space; 
}

class EntityPlayer: MovingEntity {

  // Jumping state
  public enum JumpState {ON_GROUND, JUMPING, POST_JUMP, FALLING}
  public JumpState jumpState;
  public int jumpTimer;
  public const float jumpSpeed = 0.5f;
  public const int maxJumpTime = 15;

  // Ground movement state
  public int movingDirection = 0;
  public const float groundAcceleration = 0.125f/8;
  public const float airAcceleration = 0.125f/8;
  public const float groundFriction = 0.25f/8;
  public const float airFriction = 0.125f/8;
  public const float maxHorizontalSpeed = 0.25f;

  public PlayerInput currentInput, prevInput;



  public override void Start() {
    base.Start();
    bounds.size = new Vector2(2, 4);
    applyFriction = false;
    applyGravity = true;
    tileCollisionMask = new CollisionFlags(true, true, true, true);
    applyTileCollision = true;
    maxFallSpeed = 0.75f;
  }

  public override void PreUpdate() {
    // Get input
    prevInput = currentInput;
    currentInput.Poll();

    // Horizontal movement
    bool leftInput = currentInput.left;
    bool rightInput = currentInput.right;
    if(leftInput && !rightInput)
      movingDirection = -1;
    else if(rightInput && !leftInput)
      movingDirection = 1;
    else
      movingDirection = 0;

    float acceleration;
    if(jumpState == JumpState.ON_GROUND) {
      acceleration = groundAcceleration;
      friction = groundFriction;
    }                     
    else {
      acceleration = airAcceleration;
      friction = airFriction;
    }

    applyFriction = (movingDirection == 0) || 
                    (movingDirection == 1 && velocity.x < 0) ||
                    (movingDirection == -1 && velocity.x > 0);

    velocity.x += acceleration * movingDirection;
    if(Mathf.Abs(velocity.x) > maxHorizontalSpeed)
      velocity.x = maxHorizontalSpeed * movingDirection;

    // Vertical movement
    switch(jumpState) {
      case JumpState.ON_GROUND:
        if(currentInput.jump && !prevInput.jump) {
          jumpState = JumpState.JUMPING;
          velocity.y = jumpSpeed;
          jumpTimer = maxJumpTime;
        }
        // ducking = currentInput.down;
        if(!onGround) jumpState = JumpState.FALLING;
        break;
      case JumpState.JUMPING:
        if(jumpTimer > 0 && currentInput.jump && velocity.y >= 0) {
          applyGravity = false;
          jumpTimer--;
        }
        else {
          jumpTimer = 0;
          applyGravity = true;
          jumpState = JumpState.POST_JUMP;
        }
        break;
      case JumpState.POST_JUMP:
        applyGravity = true;
        gravity = 0.5f/8;
        if(onGround) jumpState = JumpState.ON_GROUND;
        else if(velocity.y < 0) jumpState = JumpState.FALLING;
        break;
      case JumpState.FALLING:
        applyGravity = true;
        gravity = 0.25f/8;
        if(onGround) jumpState = JumpState.ON_GROUND;
        break;
    }
  }

  /*public override void PostUpdate() {
    switch(jumpState) {
      case JumpState.FALLING:
      case JumpState.POST_JUMP:
        if(onGround) jumpState = JumpState.ON_GROUND;
        break;
      case JumpState.JUMPING:
      case JumpState.ON_GROUND:
        if(velocity.y < 0) jumpState = JumpState.FALLING;
        break;
    }
  }*/
}
