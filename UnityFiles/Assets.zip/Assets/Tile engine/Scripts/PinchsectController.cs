﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PinchsectController : MonoBehaviour {

	public GameObject target; //the enemy's target
    public float moveSpeed = 1.5f; //move speed
    public float rotationSpeed = 5f;
    public float range = 50f;

	private bool stunned;
	private IEnumerator stunWait;
	private Animator animator;
	private SpriteRenderer spriteRenderer;
	public BoxCollider2D worldCollider;
	public BoxCollider2D triggerCollider;

	private	PinchsectNestController nest = null;

    public static bool tutorialActive = false;


    private GameObject soundEffects;
    private SoundEffects SE;



    // Use this for initialization
    void Start () {
		stunned = false;
		target = GameObject.FindWithTag ("Player");
		animator = GetComponent<Animator>();
  		spriteRenderer = GetComponent<SpriteRenderer>();
  		animator.Play("PinchsectFly", -1, 0f);

        soundEffects = GameObject.Find("SoundEffectsController");
        SE = (SoundEffects)soundEffects.GetComponent(typeof(SoundEffects));

    }
	
	// Update is called once per frame
	void Update () {
		target = GameObject.FindWithTag ("Player");
		Physics2D.IgnoreCollision(worldCollider, target.GetComponent<Collider2D>());

		if (target == null) {
			target = GameObject.FindWithTag ("Player");
		}
		if (Vector3.Distance(target.transform.position, transform.position) < range && !stunned) {
			Vector3 dir = (target.transform.position - transform.position).normalized;
			transform.position += dir * Time.deltaTime * moveSpeed;
		}

		float diff = target.transform.position.x - transform.position.x;
		if (diff > 0) {
			spriteRenderer.flipX = false;
		} else {
			spriteRenderer.flipX = true;
		}
	}

	void OnDestroy()
	{
		if(nest != null)
			nest.IncrementSpawnCount (-1);
	}

	void OnCollisionEnter2D(Collision2D other)
	{
		if (other.gameObject.tag == "Bullet") {
            SE.EnemyDeath();
			gameObject.SetActive (false);
		}
	}

	void OnCollisionStay2D(Collision2D other)
	{
		if (other.gameObject.tag == "Bullet") {
            SE.EnemyDeath();
            gameObject.SetActive (false);
            //Destroy(gameObject);
		}
	}

	void OnTriggerEnter2D(Collider2D other)
	{
        if (other.gameObject.tag == "PlayerMelee")
        {
            Debug.Log("Playing Sound");
            SE.EnemyDeath();
            //Destroy(gameObject);
            gameObject.SetActive(false);
        }
       /* else if (other.gameObject.tag == "PlayerMelee" && !tutorialActive)
        {
            gameObject.SetActive(false);
        }*/
    }

	public void SetNest(GameObject nestController)
	{
		nest = nestController.GetComponent<PinchsectNestController> ();
		nest.IncrementSpawnCount(1);
	}

	public void Stun()
	{
		stunned = true;
		stunWait = StunWait ();
		StartCoroutine (stunWait);
	}

	IEnumerator StunWait()
	{
		yield return new WaitForSeconds (2);
		stunned = false;
	}
}
