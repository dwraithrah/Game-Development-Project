﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//The code for this script was taken from the Unity 2d platformer tutorial at https://unity3d.com/learn/tutorials/topics/2d-game-creation/creating-basic-platformer-game
//comments added to help explain the code.  

//the player controller class will handle all of the controls tied to the player. Moving left. Moving right. Jumping.

public class PlayerControllerTutorial : MonoBehaviour
{


    //hide in inspector makes it to where you can have a public variable but it won't show up in the unity inspector.
    [HideInInspector] public bool jump = false;//tells if player is jumping or not
    //these public variables can be adjusted in the inspector for easier testing of values .
    public float moveForce = 365f;//used to calculate move speed and acceleration
    public float maxSpeed = 5f; //used to cap acceleration so player can only move so fast.
    public float minSpeed = 1f;
    public float jumpForce = 650;   //used to calculate how high and far the player can jump.
    public float friction = 1;    //used to decide how quickly player decelerates
    public Transform groundCheck, groundCheckLeft, groundCheckRight; //tells if player is staying on ground


    private bool grounded = false; //tells if player is grounded or not
    // private Animator anim;   //Stores component reference to animator.  commented out due to lack of animation in this example.
    private Rigidbody2D rb2d;  //Will store reference to rigid body
    private BoxCollider2D boxCollider;
    private Animator animator;
    private bool powerUpActive = false;//will tell if power-up is up or not
    private Transform wallCheckLeft;
    private Transform wallCheckRight;
    private bool facingRight; //is the character facing right
    private bool fall; //has the player let go of the jump key

    //for tutorial
    private GameObject tutorialController;
    private TutorialController tC;


    private GameObject soundEffects;
    private SoundEffects SE;

    // Use this for initialization when script is loadede, before game starts. 
    void Awake()
    {
        //attach component's animator to anim
        //anim = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();  //attach component's rigid body to rb2d
        boxCollider = GetComponent<BoxCollider2D>();
        animator = GetComponent<Animator>();
        wallCheckLeft = GameObject.Find("wallCheckLeft").transform;
        wallCheckRight = GameObject.Find("wallCheckRight").transform;
        facingRight = true;


        //for tutorial
        tutorialController = GameObject.Find("TutorialController");
        tC = (TutorialController)tutorialController.GetComponent(typeof(TutorialController));

        soundEffects = GameObject.Find("SoundEffectsController");
        SE = (SoundEffects)soundEffects.GetComponent(typeof(SoundEffects));
    }



    // Update is called once per frame as needed (not at a constant rate)
    void Update()
    {
        //the following bit of code causes the game to cast a ray from where the player is (transform.position), transfers it to groundCheck, and checks it against 
        //any layer that's labelled as "Ground" to see if player is on the ground or not. 
        grounded = IsGrounded();

        //checks if grounded and if the jump button was pressed. If both conditions are true, then jump will be set to true.
        if (Input.GetButtonDown("Jump") && grounded && tC.playerCanMove)
        {
            jump = true;
        }
        else if (!Input.GetButton("Jump") && !grounded)
        {
            fall = true;
        }

        //checks if player has fallen off a platform and resets the stage
        if (this.transform.position.y <= -20)
        {
            //will reload current scene
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        //checks if player health hits 0. Resets scene if it has.
        if (DataHolderController.playerHealth == 0)
        {
            //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        //if player presses A button and if there is something in inventory, power-up will be used.
        if (Input.GetKeyDown("a") && InventoryControl.hasInventory) //if there is a power-up in inventory and player hits the a button
        {
            InventoryControl.hasInventory = false; //remove power-up from inventory
            powerUpActive = true;  //power-up is activated.  
        }

        if (Input.GetButtonDown("Melee") && tC.playerCanSword)
        {
            // Melee animation
            if (!animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerMelee"))
            {
                SE.SwordSound();
                animator.Play("PlayerMelee", -1, 0f);
            }
        }

        if (Input.GetButtonDown("Gun") && tC.playerCanShoot)
        {
            // Gun animation
            if (Input.GetButton("Up"))
            {
                if (!animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerUpShoot") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerShoot") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerMelee"))
                {
                    animator.Play("PlayerUpShoot", -1, 0f);
                }
            }
            else
            {
                if (!animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerUpShoot") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerShoot") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerMelee"))
                {
                    animator.Play("PlayerShoot", -1, 0f);
                }
            }
        }

        if (grounded && tC.playerCanMove)
        {
            if (rb2d.velocity.x == 0)
            {
                // Idle animation
                if (animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerWalk") || animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerJump") || animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerFall"))
                {
                    animator.Play("PlayerIdle", -1, 0f);
                }
            }
            else
            {
                // Walk animation
                if (animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerIdle") || animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerJump") || animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerFall"))
                {
                    animator.Play("PlayerWalk", -1, 0f);
                }
            }
        }
        else
        {
            if (rb2d.velocity.y > 0)
            {
                // Jump animation
                if (!animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerJump") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerMelee") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerUpShoot") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerShoot"))
                {
                    SE.JumpSound();
                    animator.Play("PlayerJump", -1, 0f);
                }
            }
            else
            {
                // Fall animation
                if (!animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerFall") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerMelee") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerUpShoot") && !animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerShoot"))
                {
                    animator.Play("PlayerFall", -1, 0f);
                }
            }
        }

        if (animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerMelee") || animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerShoot") || animator.GetCurrentAnimatorStateInfo(0).IsName("PlayerUpShoot"))
        {
            if (animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.85f)
            {
                // Attack animation complete, return to idle
                animator.Play("PlayerIdle", -1, 0f);
            }
        }

    }

    //fixed update is updated every .02 seconds.  Used for code involving physics
    private void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal"); //store horizontal axis info in h, a value of -1 to 1.

        //anim.SetFloat("Speed", Mathf.Abs(h));//accesses the speed of the animation and sets it from a value of 0 to 1.
        if ((h * rb2d.velocity.x) < maxSpeed && tC.playerCanMove)//checks to see if player is currently going slower than max speed. 
        {
            //if it is going slower than max speed
            rb2d.AddForce(Vector2.right * h * moveForce);//adds a positive force to the player to increase acceleration. 
                                                         //note since h can become negative, when going left it will actually deccelerate the player.
        }

        if (Mathf.Abs(rb2d.velocity.x) >= maxSpeed)
        {//checking to see if going faster than max speed
         //this fun bit of math code checks to see if you're going left or right then sets the player at max velocity speed. -speed = left, +speed = right. 
            rb2d.velocity = new Vector2(Mathf.Sign(rb2d.velocity.x) * maxSpeed, rb2d.velocity.y);
        }
        else if (Mathf.Abs(rb2d.velocity.x) <= 4.9f)
        {
            rb2d.velocity = new Vector2(0f, rb2d.velocity.y);
        }


        //this next slice of commented out code can be used to figure out which way player is facing, then calls the commented out Flip function.
        if (h > 0 && !facingRight)
        {
            Flip();
        }
        else if (h < 0 && facingRight)
        {
            Flip();
        }

        if (jump && tC.playerCanJump)
        {//if jump is set to true. See conditions in update function
         //anim.SetTrigger("Jump"); //This code will cause a jump animation to play if there is one
            rb2d.AddForce(new Vector2(0f, jumpForce));//adds built in jump force from unity to create a jump
            jump = false;//resets jump to false so no double jumping allowed 
        }
        else if (fall)
        {
            rb2d.AddForce(Physics2D.gravity / 1.5f);
            fall = false;
        }


    }

    //if player collides with enemy player loses health
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            if (!powerUpActive)
            {//if power up is not active
                SE.PlayerScream();
                DataHolderController.playerHealth -= 1; //player takes damage
                                                        //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); //placeholder acting as death until health issues can be resolved
            }
            else
            {
                Destroy(other.gameObject); //enemy destroyed
                powerUpActive = false;
                InventoryControl.hasInventory = false;
            }

        }
    }


    int wallCheck()
    {
        Debug.DrawLine(transform.position, wallCheckLeft.position);

        if (Physics2D.Linecast(transform.position, wallCheckLeft.position, 1 << LayerMask.NameToLayer("Ground")))
        {
            return -1;
        }
        else if (Physics2D.Linecast(transform.position, wallCheckRight.position, 1 << LayerMask.NameToLayer("Ground")))
        {
            return 1;
        }

        return 0;
    }


    //this function, when called, will check which way the player is facing for purposes of changing sprites
    void Flip()
    {
        facingRight = !facingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    bool IsGrounded()
    {
        if (Physics2D.Linecast(transform.position, groundCheck.position, 1 << LayerMask.NameToLayer("Ground")))
        {
            return true;
        }
        else if (Physics2D.Linecast(transform.position, groundCheckLeft.position, 1 << LayerMask.NameToLayer("Ground")))
        {
            return true;
        }
        else if (Physics2D.Linecast(transform.position, groundCheckRight.position, 1 << LayerMask.NameToLayer("Ground")))
        {
            return true;
        }

        return false;
    }

    public bool FacingRight()
    {
        return facingRight;
    }
}
