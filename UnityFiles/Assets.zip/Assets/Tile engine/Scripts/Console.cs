﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Console : MonoBehaviour {

    private GameObject tutorialController;
    private TutorialController tC;

    // Use this for initialization
    void Start () {

        tutorialController = GameObject.Find("TutorialController");
        tC = (TutorialController)tutorialController.GetComponent(typeof(TutorialController));

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        //if player collider runs into coin collider, destroy coin
        if (other.gameObject.CompareTag("Player"))
        {

            tC.consoleTrigger = true;
            Debug.Log("Console is triggered");
            Debug.Log(tC.consoleTrigger);
            Debug.Log(tC.playerCanSword);
        }

    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            tC.consoleTrigger = false;
        }
    }


}
