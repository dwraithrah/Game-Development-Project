﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogManager : MonoBehaviour
{

    public GameObject dialogBox;
    public Text dialogText;
    public Text nameText;
    public Text advanceText;
    public Image Lenny;
    public Image Mikha;
    public Image Borst;
    public Image Ianella;
    public Image Creeper;


    public string[] dialogue;
    public string[] names;
    private int currentDialogue;
    private Image[] images;

    private GameObject tutorialController;
    private TutorialController tC;

    private bool tutorialBox = false;

    private bool doubleJumpScript = false;
    private bool meleeUpScript = false;
    private bool gunUpScript = false;
    private bool healthUpScript = false;
    private bool endGameScript = false;
    private bool warningScript = false;


    void Awake()
    {

    }

    // Use this for initialization
    void Start()
    {

        dialogue = new string[30];
        names = new string[30];
        images = new Image[30];
        dialogBox.SetActive(true);
        tutorialController = GameObject.Find("TutorialController");
        tC = (TutorialController)tutorialController.GetComponent(typeof(TutorialController));
        currentDialogue = 0;
        populateArrays();
        tutorialStory(dialogue[currentDialogue], names[currentDialogue], images[currentDialogue]);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && !tutorialBox)//if player hits escape button, skip to tutorial text
        {
            images[currentDialogue].enabled = false;
            tutorialBox = true;
            loadTutorial();
        }
        else if ((Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.Space)) && tutorialBox)//if player hits escape and are at the tutorial box, start tutorial stage
        {
            dialogBox.SetActive(false);
            tC.enemyCanMove = true;  //display next bit of story
            tC.playerCanJump = true;
            tC.playerCanMove = true;
            tC.playerCanShoot = true;
        }
        else if (Input.GetKeyDown(KeyCode.Space) && currentDialogue == dialogue.Length - 1) //if player hits space and we're at the end, load tutorial text
        {
            images[currentDialogue].enabled = false;
            tutorialBox = true;
            loadTutorial();
        }
        else if (Input.GetKeyDown(KeyCode.Space) && currentDialogue != dialogue.Length - 1)//if player hits space and we're not out of dialogue options, go to next
        {

            images[currentDialogue].enabled = false;
            currentDialogue++;
            tutorialStory(dialogue[currentDialogue], names[currentDialogue], images[currentDialogue]);
        }

        if(doubleJumpScript && Input.GetKeyDown(KeyCode.Space))
        {
            Ianella.enabled = false;
            dialogBox.SetActive(false);
            doubleJumpScript = false;
            Time.timeScale = 1;
        }

        if (meleeUpScript && Input.GetKeyDown(KeyCode.Space))
        {
            Ianella.enabled = false;
            dialogBox.SetActive(false);
            meleeUpScript = false;
            Time.timeScale = 1;
        }

        if (gunUpScript && Input.GetKeyDown(KeyCode.Space))
        {
            Ianella.enabled = false;
            dialogBox.SetActive(false);
            gunUpScript = false;
            Time.timeScale = 1;
        }

        if (healthUpScript && Input.GetKeyDown(KeyCode.Space))
        {
            Ianella.enabled = false;
            dialogBox.SetActive(false);
            gunUpScript = false;
            Time.timeScale = 1;
        }

        if (warningScript && Input.GetKeyDown(KeyCode.Space))
        {
            Ianella.enabled = false;
            dialogBox.SetActive(false);
            gunUpScript = false;
            Time.timeScale = 1;
        }

        if (endGameScript && Input.GetKeyDown(KeyCode.Space))
        {
            Ianella.enabled = false;
            dialogBox.SetActive(false);
            endGameScript = false;
            Time.timeScale = 1;
            SceneManager.LoadScene(0);
        }
    }

    public void populateArrays()
    {
        names[0] = "Captain Borst";
        names[1] = "Ianella";
        names[2] = "Captain Borst";
        names[3] = "Ianella";
        names[4] = "Mikha";
        names[5] = "Ianella";
        names[6] = "Lenny";
        names[7] = "Ianella";
        names[8] = "Captain Borst";
        names[9] = "Ianella";
        names[10] = "Ianella";
        names[11] = "Blobby";
        names[12] = "Ianella";
        names[13] = "Mikha";
        names[14] = "Captain Borst";
        names[15] = "Ianella";
        names[16] = "Captain Borst";
        names[17] = "Ianella";
        names[18] = "Blobby";
        names[19] = "Ianella";
        names[20] = "Lenny";
        names[21] = "Ianella";
        names[22] = "Lenny";
        names[23] = "Ianella";
        names[24] = "Blobby";
        names[25] = "Ianella";
        names[26] = "Mikha";
        names[27] = "Ianella";
        names[28] = "Mikha";
        names[29] = "Ianella";

        images[0] = Borst;
        images[1] = Ianella;
        images[2] = Borst;
        images[3] = Ianella;
        images[4] = Mikha;
        images[5] = Ianella;
        images[6] = Lenny;
        images[7] = Ianella;
        images[8] = Borst;
        images[9] = Ianella;
        images[10] = Ianella;
        images[11] = Creeper;
        images[12] = Ianella;
        images[13] = Mikha;
        images[14] = Borst;
        images[15] = Ianella;
        images[16] = Borst;
        images[17] = Ianella;
        images[18] = Creeper;
        images[19] = Ianella;
        images[20] = Lenny;
        images[21] = Ianella;
        images[22] = Lenny;
        images[23] = Ianella;
        images[24] = Creeper;
        images[25] = Ianella;
        images[26] = Mikha;
        images[27] = Ianella;
        images[28] = Mikha;
        images[29] = Ianella;



        dialogue[0] = "Ianella, do you copy?";
        dialogue[1] = "Boss man, uh, hi. Nice day huh? How's it going?";
        dialogue[2] = "Fantastic! Seems someone decided to take one of the suits and head over to the space station without authorization. Could you come over to the bridge? We're doing a bit of a head count.";
        dialogue[3] = "Oh.  Um.  Funny story! See, I noticed something was wrong with one of the space suits and decided to check it out. A little messing with it and some testing after and wouldn't you know it I ended up on the space station.";
        dialogue[4] = "That's funny. I'm absolutely certain I inspected all suits and tested them for useability at least four times during this trip. Including last night!";
        dialogue[5] = "Huh, well, you missed a spot!";
        dialogue[6] = "Ooooh Captain. I think we should leave her on the station for a few weeks. That'll teach her!";
        dialogue[7] = "Can it spaz.  Besides, this place is loaded. I came into docking bay and it's filled with unopened crates and other stuff.  We're gonna be rich!";
        dialogue[8] = "That so?  Well, since you're over there, why don't you make yourself useful and check one of them crates to see what's in them?";
        dialogue[9] = "Aye aye boss man!";
        dialogue[10] = "(Did I just hear something?)";
        dialogue[11] = "Burgle. Shlurp. Shlip. Shlop.";
        dialogue[12] = "Oooooooh no. Oh-no-oh-no-oh-no!  Captaaaaaaaain!  There's this weird blobby thing in here!";
        dialogue[13] = "Blobby thing? Is that the scientific term for it Ian?";
        dialogue[14] = "Shut it Mikha and go fix something.  Ian, is this thing attacking you?";
        dialogue[15] = "Well, no. It's just making icky slimy sounds and rubbing against this crate near me.";
        dialogue[16] = "Then don't worry about it and get back to checking crates for valuables!";
        dialogue[17] = "Well, fine, but if this thing-";
        dialogue[18] = "Burgle. Shlurp. Shlip. Shlop. (The creature dissolves through the crate and its contents. It then starts to wobble towards Ianella).";
        dialogue[19] = "The blobby thing ate through the crate and everything in it! And now it's moving towards me!";
        dialogue[20] = "Don't you have a blaster with you?";
        dialogue[21] = "Oh yeah. I do.";
        dialogue[22] = "Well what you do is point the blaster at the thing, pull that lever thing called a trigger and-";
        dialogue[23] = "Can it spaz!";
        dialogue[24] = "Burgle. Shlurp. Shlip. Shlop.(The laser blast strikes the blob but has little effect.)";
        dialogue[25] = "The blaster isn't hurting it! Only slowing it down!";
        dialogue[26] = "Interesting. An amorphous entity that absorbs concentrated thermal energy. Perhaps it'd be subsceptible to kinetic energy.";
        dialogue[27] = "All right smart guy, say again?";
        dialogue[28] = "Try using your vibro-blade on it.";
        dialogue[29] = "Hmm. Seems to be out of juice. I'll search around and see if I can find a power clip for it.";

    }

    public void loadTutorial()
    {
        string tutorialText = "To move left and right use the 'A' and 'D' keys respectively. To jump hit the 'Space'button.  To shoot the gun hit the 'C' button.  " +
            "Go to the power-up in the top right corner of the stage to activate Ianella's vibroblade. Once you get it press 'X' to attack.  " +
            "Afterwards head to the console and press 'E' to open the door to the next level";
        string tutorialName = "TUTORIAL";
        advanceText.text = "Press 'Space' or 'Escape' to end tutorial";
        dialogText.text = tutorialText;
        nameText.text = tutorialName;
    }

    public void DoubleJumpScript()
    {
        Time.timeScale = 0;
        dialogBox.SetActive(true);
        doubleJumpScript = true;
        string name = "Ianella";
        string dialogue = "Hmmmm. This is handy. I can now jump farther with this extra boost. (To perform a double jump simply hit the 'Space Bar' a second time while in the middle of the first jump.)" +
            "\n (Note, you can only jump one extra time.)";
        advanceText.text = "Press 'Space' to continue.";
        tutorialStory(dialogue, name, Ianella);
    }

    public void MeleeUpScript()
    {
        Time.timeScale = 0;
        dialogBox.SetActive(true);
        meleeUpScript = true;
        string name = "Ianella";
        string dialogue = "Hmmmm. This is handy. This powers up my blade. It'll cut faster. Not that I need this for anything, right?  (The damage of the sword has now been increased).";
        advanceText.text = "Press 'Space' to continue.";
        tutorialStory(dialogue, name, Ianella);
    }

    public void GunUpScript()
    {
        Time.timeScale = 0;
        dialogBox.SetActive(true);
        gunUpScript = true;
        string name = "Ianella";
        string dialogue = "Hmmmm. This is handy. A power boost for my laser. Maybe this will keep those blobbies stunned longer. (The length of time an enemy will be stunned has increased).";
        advanceText.text = "Press 'Space' to continue.";
        tutorialStory(dialogue, name, Ianella);
    }

    public void HealthUpScript()
    {
        Time.timeScale = 0;
        dialogBox.SetActive(true);
        healthUpScript = true;
        string name = "Ianella";
        string dialogue = "Ooooh! I feel refreshed! Like I can take on the world! (Your max health has just been increased. You can take more hits!)";
        advanceText.text = "Press 'Space' to continue.";
        tutorialStory(dialogue, name, Ianella);
    }

    public void EndGameScript()
    {
        Time.timeScale = 0;
        dialogBox.SetActive(true);
        endGameScript = true;
        string name = "Ianella";
        string dialogue = "I did it! I killed the giant blob!"+
            "\n (CONGRATULATIONS! You have fought your way through part of the station. But, what are these blobs? What happened to the station's crew?  To be continued...)";
        advanceText.text = "Press 'Space' to continue.";
        tutorialStory(dialogue, name, Ianella);
    }

    public void WarningScript()
    {
        Time.timeScale = 0;
        dialogBox.SetActive(true);
        warningScript = true;
        string name = "Ianella";
        string dialogue = "I hear something loud through that door. Maybe I should look around for something that'll help me out in this fight."+
            "\n(This stage has several power-ups that can make the up-coming fight easier. You can tackle the challenge without them, but it will be harder)";
        advanceText.text = "Press 'Space' to continue.";
        tutorialStory(dialogue, name, Ianella);
    }

    public void tutorialStory(string dialog, string name, Image image)
    {
        dialogText.text = dialog;
        nameText.text = name;
        image.enabled = true;
        
    }

   

}
