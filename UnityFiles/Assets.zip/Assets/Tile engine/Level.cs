﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour {
  public Vector2 Scroll { get { return bgman.scroll; }
                          set { bgman.scroll = value; }
                        }

  private BackgroundManager bgman;
  //private bool clearKeyPressed;

  // Use this for initialization
  void Start() {
    bgman = GetComponent<BackgroundManager>();
  }

  void TryScroll(float dx, float dy) {
    Vector2 n = Scroll + new Vector2(dx, dy);
    float w = bgman.mapInfo.width;
    float h = bgman.mapInfo.height;

    if(n.x < 0) n.x = 0;
    else if(n.x + 32 > w) n.x = w - 32;

    if(n.y < 0) n.y = 0;
    else if(n.y + 30 > h) n.y = h - 30; 

    Scroll = n;
  }

  void FixedUpdate() {/*
    float dx = 0, dy = 0;
    if(Input.GetKey(KeyCode.W)) 
      dy = 0.5f;
    else if(Input.GetKey(KeyCode.S))
      dy = -0.5f;

    if(Input.GetKey(KeyCode.D)) 
      dx = 0.5f;
    else if(Input.GetKey(KeyCode.A))
      dx = -0.5f;

    TryScroll(dx, dy);*/
  }


}
