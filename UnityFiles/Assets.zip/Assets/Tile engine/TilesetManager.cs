﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class TileCollision {
  public const byte Empty = 0,
                    Solid = (byte) 'e',
                    Floor = (byte) 'a',
                    LeftWall = (byte) 'c',
                    RightWall = (byte) 'b',
                    Ceiling = (byte) 'd';
}

// This class stores tilesets 
public class TilesetManager { 
  private static Dictionary<int, Color32[]> tilesets = new Dictionary<int, Color32[]>();
  private static Dictionary<int, byte[]> tileCollision = new Dictionary<int, byte[]>();

  /**
   * Loads a tileset from a texture. 
   * The texture must be 256x256; if it isn't an exception is thrown.
   *
   * If a tileset with the given id is already loaded, this does nothing.
   */
  private static void LoadTileset(int id) {
    Texture2D texture = (Texture2D) Resources.Load("tiles/"+id);
    byte[] collision = ((TextAsset) Resources.Load("tiles/c"+id)).bytes;
    if(texture == null || collision == null) {
      Debug.LogError("Failed to load tileset: "+id);
      return;
    }

    // Ensure that tilesets are the correct size
    if(texture.width != 256 && texture.height != 256)
      throw new Exception("Tileset textures must be 256x256");

    // Get all texture pixels as an array here.
    //
    //   Texture2D.GetPixels() allocates a new array each time it's called;
    // for our purposes that's a very bad thing. We'd rather have direct access
    // to the pixel data, without having to allocate heap space or call methods
    // to do so.
    Color32[] array = texture.GetPixels32(0);

    // Unity returns the texture data starting at the bottom left.
    // We want the array to go right and down, so reverse the rows here
    // (swap each row of 256 pixels with its opposite.)
    for(int i = 0; i < 128; i++) {
      int a = i << 8, 
            b = (255 - i) << 8;
      for(int j = 0; j < 256; j++) {
        Color32 t = array[a + j];
        array[a + j] = array[b + j];
        array[b + j] = t;
      }
    }
    tilesets.Add(id, array);
    tileCollision.Add(id, collision);
    Debug.Log("Tileset loaded: " + id);

  }

  /** Returns whether a tileset with the given id is loaded. */
  public static bool IsTilesetLoaded(int index) { return tilesets.ContainsKey(index); }

  /**
   * Returns the tileset associated with the given id if any, 
   * otherwise returns null.
   */
  public static Color32[] GetTileset(int id) {
    if(!IsTilesetLoaded(id))
      LoadTileset(id);
    return tilesets[id];
  }

  public static byte[] GetTileCollision(int id) {
    if(!IsTilesetLoaded(id))
      LoadTileset(id);
    return tileCollision[id];
  }
}