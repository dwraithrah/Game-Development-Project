﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialCrawlerScript : MonoBehaviour {

    //needed to move enemy back and forth
    public enum OccilationFuntion { Sine, Cosine }

    Vector2 startingPosition;
    bool dirLeft;

    public float moveSpeed = .5f;
    private bool stunned;
    private IEnumerator stunWait;
    private Animator animator;
    private SpriteRenderer spriteRenderer;

    private GameObject tutorialController;
    private TutorialController tC;

    private void Awake()
    {

    }

    // Use this for initialization
    void Start()
    {

        startingPosition = transform.position;
        dirLeft = true; //enemy starts moving left
        stunned = false;
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator.Play("CrawlerMove", -1, 0f);

        //for tutorial
        tutorialController = GameObject.Find("TutorialController");
        tC = (TutorialController)tutorialController.GetComponent(typeof(TutorialController));
    }

    // Update is called once per frame
    void Update()
    {

        if (!stunned && tC.enemyCanMove)
        {
            //script to make enemy move back and forth
            if (dirLeft)
            {//if headed left
                transform.Translate(-Vector2.right * moveSpeed * Time.deltaTime); //keep moving left
                spriteRenderer.flipX = true;
            }
            else
            { //if headed right
                transform.Translate(Vector2.right * moveSpeed * Time.deltaTime);
                spriteRenderer.flipX = false;
            }
        }
    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.tag == "Bullet")
        {
            Stun();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Bullet")
        {
            Stun();
        }

        if ((collision.gameObject.tag != "Player") && (collision.gameObject.tag != "Enemy")) //if collide with anything other than player
        {
            dirLeft = !dirLeft; //if enemy runs into something not the player, change from false to true or vice versa
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "PlayerMelee")
        {
            Destroy(gameObject);
        }
    }

    private void Respawn()
    {
        // Return the enemy to its starting position, and reset the direction it was initially facing
        // Things like health, etc. can be reset here later
        transform.position = startingPosition;
        dirLeft = true;
    }

    public void Stun()
    {
        stunned = true;
        stunWait = StunWait();
        StartCoroutine(stunWait);
    }

    IEnumerator StunWait()
    {
        yield return new WaitForSeconds(2);
        stunned = false;
    }
}
