﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuController : MonoBehaviour {

	public void ChangeScene(string scenename) {
		Application.LoadLevel(scenename);
	}

	public void Quit() {
		Application.Quit();
	}
}
