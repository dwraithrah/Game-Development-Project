﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

/* We will need to implement our own behavior system in order to control update order. */ 
   
public class Entity: MonoBehaviour {
  public double x, y, z;
  public Bounds bounds;
  public List<EntityBehavior> behaviors = new List<EntityBehavior>();
  public List<bool> enabledNextFrame = new List<bool>();
  
  public virtual void Start() {}

  public void ManualUpdate() {
    UpdateEnabledFlags();
    UpdateBehaviors();
    transform.localPosition = new Vector3((float) x, (float) y, (float) z);
  }

  private void UpdateEnabledFlags() {
    int n = behaviors.Count();
    for(int i = 0; i < n; i++) {
      behaviors[i].enabled = enabledNextFrame[i];
    }
  }

  private void UpdateBehaviors() {
    int n = behaviors.Count;
    for(int i = 0; i < n; i++) {
      if(behaviors[i].enabled)
        behaviors[i].Update();
    }
  }
}

public class EntityBehavior: ScriptableObject {
  public bool enabled;

  public virtual void Update() {}
}
