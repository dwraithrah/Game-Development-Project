﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneUnload : MonoBehaviour {
    public int levelToUnload;  //this is so you can just drag and drop the level to load in the inspector

    bool unloaded;  //used to load scene if not loaded

    private GameObject dataHolderController;
    private DataHolderController dH;


    // Use this for initialization
    void Start()
    {

        //dataHolderController = GameObject.Find("DataHolder");
        //dH = (DataHolderController)dataHolderController.GetComponent(typeof(DataHolderController));

    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        //if player collider runs into door collider, the next scene will load
        if (other.gameObject.CompareTag("Player"))
        {

            if (!unloaded)
            {
                //load next scene
                unloaded = true;
                SceneManager.UnloadSceneAsync(2);
                //StartCoroutine(RemoveScene());

            }

        }

    }

    IEnumerator RemoveScene()
    {
        SceneManager.UnloadSceneAsync(levelToUnload);
        yield return null;
    }
}
