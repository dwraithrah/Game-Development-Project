﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[Serializable] public struct CollisionFlags {
  public bool left, right, top, bottom;
  public CollisionFlags(bool l, bool r, bool t, bool b) {
    left = l; right = r; top = t; bottom = b;
  }
}

/*public struct CollisionList {
  public int count;
  public fixed RaycastHit2D[] hits[8];
}*/

public class MovingEntity: MonoBehaviour
{
  // Collision geometry of this entity
  public Bounds2D bounds;
  [HideInInspector] public BoxCollider2D collider;
  public Vector2 boundsOffset;
  public int solidMask;

  // Sprite associated with this entity
  public SpriteRenderer spriteRenderer;
  public Sprite sprite { 
    get {return spriteRenderer ? spriteRenderer.sprite : null;}
    set {if(spriteRenderer) spriteRenderer.sprite = value;}
  }
  public float z; // z-order of this entity. this should only affect rendering

  // References to the level data 
  protected BackgroundManager bg;
  public CollisionFlags tileCollisionFlags, tileCollisionMask;
  public bool canAutoClimb; // True if we are colliding with "stairs" and can step up  

  // Position and velocity of this entity
  public Vector2 velocity, position;
  protected Vector2 oldVelocity, oldPosition; 

  public float friction;       // Friction in the X direction
  public float gravity;        // Gravity in the Y direction
  public float maxFallSpeed; // Terminal falling speed

  public bool onGround = false;
  public bool applyFriction = false;
  public bool applyGravity = true;
  public bool applyTileCollision = true;

  //protected CollisionList topCollisions, bottomCollisions, leftCollisions, rightCollisions;

  public virtual void Start() {
    collider = GetComponent<BoxCollider2D>();
    bg = GameObject.Find("BackgroundManager").GetComponent<BackgroundManager>();
    position = transform.localPosition; // initialize this entity's position
  }

  public void FixedUpdate() {
    bounds.center = position + boundsOffset;
    oldVelocity = velocity;
    oldPosition = position;

    PreUpdate();
    UpdatePhysics();
    PostUpdate();

    // Synchronize the GameObject's properties with our own
    collider.size = bounds.size;
    collider.offset = boundsOffset;
    transform.localPosition = new Vector3(position.x, position.y, z);
  }

  public virtual void PreUpdate() {}
  public virtual void PostUpdate() {}

  public virtual void UpdatePhysics() {
    // get collisions

    if(applyFriction) {
      if(Mathf.Abs(velocity.x) > friction) {
          if(velocity.x > 0)
            velocity.x -= friction;
          else
            velocity.x += friction;
      }
      else
        velocity.x = 0;// Apply friction
    }

    // check for collisions
    Vector2 displacement = velocity;
    // CheckEntityCollisionsX();
    if(applyTileCollision) {
      float tcd = CheckTileCollisionX(bounds, displacement.x);
      MoveX(tcd);
    }
    else
      MoveX(displacement.x);
    if(canAutoClimb)
      MoveY(1 - bounds.bottomFrac);

    
    // do the same in the Y direction
    // CheckEntityCollisionsY();
    if(applyGravity && !onGround) {
      if(velocity.y < -maxFallSpeed) velocity.y = -maxFallSpeed;
      else velocity.y -= gravity;
    }
    displacement.y = velocity.y;
    if(applyTileCollision) {
      float tcd = CheckTileCollisionY(bounds, displacement.y);
      MoveY(tcd);
    }
    else
      MoveY(displacement.y);

    onGround = tileCollisionFlags.bottom;
  }

  // Applies a linear acceleration to this entity toward the specified target velocity.
  public void ApplyAcceleration(Vector2 delta, Vector2 limit) {
    Vector2 direction = new Vector2(Mathf.Sign(limit.x - velocity.x),
                                    Mathf.Sign(limit.y - velocity.y));
    velocity += delta;
    if(Mathf.Sign(limit.x - velocity.x) != direction.x)
      velocity.x = limit.x;
    else
      velocity.x += delta.x * direction.x;

    if(Mathf.Sign(limit.y - velocity.y) != direction.y)
      velocity.y = limit.y;
    else
      velocity.y += delta.y * direction.y;
  }

  protected void Move(Vector2 delta) {
    bounds.center += delta;
    position += delta;
  }

  protected void Move(float dx, float dy) {
    Move(new Vector2(dx, dy));
  }

  protected float MoveX(float dx) {
    bounds.center.x += dx;
    position.x += dx;
    return dx;
  }

  protected float MoveY(float dy) {
    bounds.center.y += dy;
    position.y += dy;
    return dy;
  }

  // Checks for tile collisions in the X direction.
  // Returns the distance between the first tile collision and the edge of this entity's bounding box.
  private float CheckTileCollisionX(Bounds2D b, float dx) {
    int txOldEdge = 0, txNewEdge = 0; // near and far edges of scanning rectangle
    float xEdgeInTile = 0; // x coordinate offset within tile of forward edge
    // Calculate x coordinate of scan rectangle
    if(dx == 0) return 0;
    else if(dx < 0) {
      txOldEdge = b.LeftInt(0);
      txNewEdge = b.LeftInt(dx);
      xEdgeInTile = b.leftFrac;
    }
    else if(dx > 0) {
      txOldEdge = b.RightInt(0);
      txNewEdge = b.RightInt(dx);
      xEdgeInTile = b.rightFrac;
    }
     
    int tyMin = b.bottomInt, tyMax = b.topInt; // y tile coordinates of top & bottom edges

    // clear collision flags by default
    tileCollisionFlags.left = tileCollisionFlags.right = canAutoClimb = false;
    // Scan this rectangle for obstacles
    if(dx < 0 && tileCollisionMask.left) { // moving left
      for(int tx = txOldEdge; tx >= txNewEdge; tx--) {
        if(ScanTileCollisionColumn(tx, tyMin, tyMax, dx)) {
          tileCollisionFlags.left = true;
          velocity.x = 0;
          return (tx - txOldEdge) + (1 - xEdgeInTile);
        }
      }
    }
    else if(dx > 0 && tileCollisionMask.right) { // moving right
      for(int tx = txOldEdge; tx <= txNewEdge; tx++) {
        if(ScanTileCollisionColumn(tx, tyMin, tyMax, dx)) {
          tileCollisionFlags.right = true;
          velocity.x = 0;
          return (tx - txOldEdge) - xEdgeInTile;
        }
      }
    }
    return dx;
  }

  // Checks tile collisions in the Y direction.
  private float CheckTileCollisionY(Bounds2D b, float dy) {
    // If y speed is zero, handle ground check specially
    if(dy == 0) { // check if on ground
      tileCollisionFlags.top = tileCollisionFlags.bottom = false; // ignore top collisions
      if(tileCollisionMask.bottom) {
        // if we're one pixel above a ground tile, count that as being on ground
        if(ScanTileCollisionRow(b.BottomInt(-.125f), b.leftInt, b.rightInt, 0)) {
          tileCollisionFlags.bottom = true;
          return velocity.y = 0;
        }
        // otherwise move upwards if we're overlapping a floor tile. 
        // We use a slightly smaller hitbox for this (1 pixels on each side)  
        else if(ScanTileCollisionRow(b.bottomInt, b.LeftInt(.25f), b.RightInt(-.25f), 0) && (b.bottomFrac > 0.5)) { 
          tileCollisionFlags.bottom = true;
          velocity.y = 0;
          MoveY(0.125f);
        }
        return 0;
      }
    }

    int tyOldEdge = 0, tyNewEdge = 0;
    float yEdgeInTile = 0;
    if(dy < 0) {
      tyOldEdge = b.BottomInt(0);
      tyNewEdge = b.BottomInt(dy);
      yEdgeInTile = b.bottomFrac;
    }
    else if(dy > 0) {
      tyOldEdge = b.TopInt(0);
      tyNewEdge = b.TopInt(dy);
      yEdgeInTile = b.topFrac;
    }

    int txMin = b.leftInt, txMax = b.rightInt;
    tileCollisionFlags.bottom = tileCollisionFlags.top = false;
    
    if(dy < 0 && tileCollisionMask.bottom) { 
      for(int ty = tyOldEdge; ty >= tyNewEdge; ty--) {
        if(ScanTileCollisionRow(ty, txMin, txMax, dy)) {
          tileCollisionFlags.bottom = true;
          velocity.y = 0;
          return (ty - tyOldEdge) + (1 - yEdgeInTile);
        }
      }
    }
    else if(dy > 0 && tileCollisionMask.top) {
      for(int ty = tyNewEdge; ty <= tyNewEdge; ty++) {
        if(ScanTileCollisionRow(ty, txMin, txMax, dy)) {
          tileCollisionFlags.top = true;
          velocity.y = 0;
          return (ty - tyOldEdge) - (yEdgeInTile); 
        }
      }
    }
    return dy;
  }

  protected bool ScanTileCollisionColumn(int tx, int tyMin, int tyMax, float dx) { 
    for(int ty = tyMax; ty >= tyMin; ty--) {
      switch(bg.GetTileCollision(tx, ty)) {
        case TileCollision.Solid: // solid
          /*if(ty == tyMin && onGround && velocity.y >= 0) {
            canAutoClimb = true;
            return false;
          } */
          return true;
        case TileCollision.RightWall: // right wall
          if(dx > 0) return true;
          break;
        case TileCollision.LeftWall: // left wall
          if(dx < 0) return true;
          break;
      }
    } 
    return false;
  }

  protected bool ScanTileCollisionRow(int ty, int txMin, int txMax, float dy) {
    for(int tx = txMin; tx <= txMax; tx++) {
      switch(bg.GetTileCollision(tx, ty)) {
        case TileCollision.Solid: // solid
          return true;
        case TileCollision.Floor: // floor
          if(dy <= 0) return true;
          break;
        case TileCollision.Ceiling: // ceiling
          if(dy > 0) return true;
          break;
      }
    }
    return false;
  }
}
