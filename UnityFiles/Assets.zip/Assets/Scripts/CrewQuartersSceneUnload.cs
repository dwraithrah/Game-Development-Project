﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CrewQuartersSceneUnload : MonoBehaviour {

    public int levelToUnload;  //this is so you can just drag and drop the level to load in the inspector

    bool unloaded;  //used to load scene if not loaded

    private GameObject dataHolderController;
    private DataHolderController dH;


    // Use this for initialization
    void Start()
    {

        //dataHolderController = GameObject.Find("DataHolder");
        //dH = (DataHolderController)dataHolderController.GetComponent(typeof(DataHolderController));
        Debug.Log("Starting Crew Quarters Unload Script");
        Debug.Log(unloaded);

    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        //if player collider runs into door collider, the next scene will load
        if (other.gameObject.CompareTag("Player"))
        {

            if (!unloaded)
            {
                Debug.Log("Trigger happened and it is not unloaded yet");
                //load next scene
                unloaded = true;
                Debug.Log("Unloaded is now true");
                //SceneManager.UnloadSceneAsync(3);
                Debug.Log("Coroutine to unload scene 3 now started");
                StartCoroutine(RemoveScene());

            }

        }

    }

    IEnumerator RemoveScene()
    {
        SceneManager.UnloadSceneAsync(levelToUnload);
        Debug.Log("Scene3 now unlloaded");
        yield return null;
    }
}


