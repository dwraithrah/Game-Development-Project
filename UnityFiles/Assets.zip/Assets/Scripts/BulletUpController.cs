﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletUpController : MonoBehaviour {


	private string direction;
	public Vector3 velocity;
	// Use this for initialization
	void Start () {
		velocity = new Vector3 (0f, 0.33f);
	}

	// Update is called once per frame
	void FixedUpdate () {
			transform.position += velocity;
	}

	void OnCollisionEnter2D (Collision2D coll)
	{
		if (coll.gameObject.tag == "Enemy") {
			//Destroy (coll.gameObject);
		}

		if (coll.gameObject.tag != "Player") {
			Destroy (gameObject);
		}
	}

	void OnCollisionStay2D(Collision2D coll)
	{
		if (coll.gameObject.tag == "Enemy") {
			//Destroy (coll.gameObject);
		}

		if (coll.gameObject.tag != "Player") {
			Destroy (gameObject);
		}
	}
}

