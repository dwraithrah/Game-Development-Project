﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PinchsectNestController : MonoBehaviour {

	public float spawnTime;
	public Transform pinchsect;
	public BoxCollider2D selfCollider;

	private float lastSpawned;
	private bool nearPlayer, stunned;
	private int spawnCount;
	private Transform[] spawned;
	private IEnumerator stunWait;
	private Animator animator;
	private SpriteRenderer spriteRenderer;

    private GameObject soundEffects;
    private SoundEffects SE;

    // Use this for initialization
    void Start () {
		spawnCount = 0;
		stunned = false;
		lastSpawned = Time.time;
		animator = GetComponent<Animator>();
		animator.Play("NestIdle", -1, 0f);

        soundEffects = GameObject.Find("SoundEffectsController");
        SE = (SoundEffects)soundEffects.GetComponent(typeof(SoundEffects));
    }
	
	// Update is called once per frame
	void Update () {
		if (nearPlayer && (Time.time - lastSpawned > spawnTime && spawnCount < 3) && !stunned) {
			// Spawn animation
			animator.Play("NestSpawn", -1, 0f);
			
			lastSpawned = Time.time;
		}

		if (animator.GetCurrentAnimatorStateInfo(0).IsName("NestSpawn")) {
			if (animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.85f) {
                animator.Play("NestSplat", -1, 0f);

                SE.BirthSound();

                Transform spawned = Instantiate (pinchsect, transform.position + new Vector3 (0, 1, 1), Quaternion.identity);
				spawned.GetComponentInParent<PinchsectController>().SetNest (gameObject);
            }
		}

		if (animator.GetCurrentAnimatorStateInfo(0).IsName("NestSplat")) {
			if (animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.85f) {
                animator.Play("NestIdle", -1, 0f);
            }
		}
	}

	void OnTriggerEnter2D (Collider2D other)
	{
		if (other.gameObject.tag == "Player") {
			nearPlayer = true;
		}

		if (other.gameObject.tag == "PlayerMelee" && selfCollider.IsTouching(other)) {
            SE.EnemyDeath();
			gameObject.SetActive (false);
		}
	}

	void OnTriggerExit2D (Collider2D other)
	{
		if (other.gameObject.tag == "Player") {
			nearPlayer = false;
		}
	}

	public void IncrementSpawnCount(int i)
	{
		spawnCount += i;
		if (spawnCount < 0) {
			spawnCount = 0;
		}
	}

	void OnCollisionEnter2D(Collision2D other)
	{
		if (other.gameObject.tag == "Bullet") {
			Stun ();
		}
	}

	void OnCollisionStay2D(Collision2D other)
	{
		if (other.gameObject.tag == "Bullet") {
			Stun ();
		}
	}

	public void Stun()
	{
		stunned = true;
		stunWait = StunWait ();
		StartCoroutine (stunWait);
	}

	IEnumerator StunWait()
	{
		yield return new WaitForSeconds (2);
		stunned = false;
	}
}
