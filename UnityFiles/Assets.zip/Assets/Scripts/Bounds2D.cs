﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

// This class contains physics code that is common to all entities.
[Serializable] public struct Bounds2D { 
  public Vector2 center, halfSize;

  public Bounds2D(Vector2 center, Vector2 halfSize) {
    this.center = center;
    this.halfSize = halfSize;
  }

  public Bounds2D(float cx, float cy, float hx, float hy) {
    center = new Vector2(cx, cy);
    halfSize = new Vector2(hx, hy);
  }
  public Vector2 size { get { return halfSize * 2; } set { halfSize = value * 0.5f; } }
  public Vector2 min {get {return center - halfSize;}}
  public Vector2 max {get {return center + halfSize;}}
  public float top {get {return center.y + halfSize.y;}}
  public int topInt {get {return Mathf.FloorToInt(center.y + halfSize.y);}}
  public float topFrac {get {return top - topInt;}}

  public float TopFrac(float dy) { return (top + dy) - TopInt(dy); }
  public int TopInt(float dy) { return Mathf.FloorToInt(center.y + dy + halfSize.y); }

  public float bottom {get {return center.y - halfSize.y;}}
  public int bottomInt { get { return Mathf.FloorToInt(center.y - halfSize.y); } }
  public float bottomFrac { get { return bottom - bottomInt; } }
  public int BottomInt(float dy) { return Mathf.FloorToInt(center.y + dy - halfSize.y); }
  public float BottomFrac(float dy) { return (bottom + dy) - BottomInt(dy); }

  public float left { get { return center.x - halfSize.x; } }
  public int leftInt { get { return Mathf.FloorToInt(center.x - halfSize.x); } }
  public float leftFrac { get { return left - leftInt; } }
  public int LeftInt(float dx) { return Mathf.FloorToInt(center.x - halfSize.x + dx); }

  public float right { get { return center.x + halfSize.x; } }
  public int rightInt { get { return Mathf.FloorToInt(center.x + halfSize.x); } }
  public float rightFrac { get { return right - rightInt; } }
  public int RightInt(float dx) { return Mathf.FloorToInt(center.x + halfSize.x + dx); }

  public RaycastHit2D CheckObjectCollisionLeft(int layerMask) {
    float x = left, y1 = top, y2 = bottom;
    return Physics2D.Linecast(new Vector2(x, y1), new Vector2(x, y2), layerMask);
  }

  public RaycastHit2D CheckObjectCollisionRight(int layerMask) {
    float x = right, y1 = top, y2 = bottom;
    return Physics2D.Linecast(new Vector2(x, y1), new Vector2(x, y2), layerMask);
  }

  public RaycastHit2D CheckObjectCollisionTop(int layerMask) {
    float y = top, x1 = left, x2 = right;
    return Physics2D.Linecast(new Vector2(x1, y), new Vector2(x2, y), layerMask);
  }

  public RaycastHit2D CheckObjectCollisionBottom(int layerMask) {
    float y = bottom, x1 = left, x2 = right;
    return Physics2D.Linecast(new Vector2(x1, y), new Vector2(x2, y), layerMask);
  }

  public static Bounds2D operator + (Bounds2D b, Vector2 offset) {
    return new Bounds2D(b.center + offset, b.halfSize);
  }

  public static Bounds2D operator - (Bounds2D b, Vector2 offset) { 
    return new Bounds2D(b.center - offset, b.halfSize);
  }

  public Bounds2D Expand(Vector2 delta) { return new Bounds2D(center, halfSize + delta); }
  public Bounds2D Shrink(Vector2 delta) { return new Bounds2D(center, halfSize - delta); }

  public Bounds2D(Bounds b) {
    center = b.center;
    halfSize = b.extents;
  }
  
  public static implicit operator Bounds(Bounds2D b) {
    return new Bounds(b.center, b.size);
  }
  
  public static implicit operator Rect(Bounds2D b) {
    return new Rect(b.center - b.halfSize, b.size);
  }
  
  public bool Intersects(Bounds2D b) {
    return !(  Mathf.Abs(center.x - b.center.x) > halfSize.x + b.halfSize.x
            || Mathf.Abs(center.y - b.center.y) > halfSize.y + b.halfSize.y);
  } 
}
