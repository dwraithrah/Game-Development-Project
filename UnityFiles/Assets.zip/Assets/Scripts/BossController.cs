﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossController : MonoBehaviour {

	public int health;
	public GameObject melee;
	public GameObject charge;
	public Transform projectile;
	public Transform player;

	private Rigidbody2D rb2d;
	private Vector3 offset;
	private Animator animator;
	private float lastHit;
	private bool canFire;
	private bool canMelee;
	private bool canCharge;
	private bool stunned;

	private bool facingRight;
	private int phase;

	private GameObject soundEffects;
    private SoundEffects SE;

    private GameObject dialogManager;
    private DialogManager dM;

    // Use this for initialization
    void Start () {
		health = 50;
		lastHit = Time.time;
		phase = 1;

		facingRight = false;
		canFire = true;
		canMelee = true;
		canCharge = true;
		stunned = false;

		melee.SetActive (false);
		charge.SetActive (false);

		offset = new Vector3 (-1, 1);
		rb2d = gameObject.GetComponent<Rigidbody2D> ();
		animator = GetComponent<Animator>();
		animator.Play("BossFirstIdle", -1, 0f);

		soundEffects = GameObject.Find("SoundEffectsController");
        SE = (SoundEffects)soundEffects.GetComponent(typeof(SoundEffects));

        SE.BossRoar();

        dialogManager = GameObject.Find("Dialogue Manager");
        dM = (DialogManager)dialogManager.GetComponent(typeof(DialogManager));
    }
	
	// Update is called once per frame
	void Update () {
		if (health <= 0) {
			SE.BossRoar();
			SE.BirthSound();
            dM.EndGameScript();
			gameObject.SetActive (false);

		} 
		else if (health <= 25) {
			phase = 2;

			if (animator.GetCurrentAnimatorStateInfo(0).IsName("BossFirstIdle")) {
	            animator.Play("BossSecondIdle", -1, 0.0f);
	        }
		}

		if (!stunned) {
			if (animator.GetCurrentAnimatorStateInfo (0).IsName ("BossSecondAttack")) {
				if (animator.GetCurrentAnimatorStateInfo (0).normalizedTime >= 0.85f) {
					animator.Play ("BossSecondIdle", -1, 0.0f);
				}
			}

			if ((canFire || canMelee) && phase == 1) {

				if (/*Vector2.Distance (player.position, gameObject.transform.position) > 5.0f*/ true) {
					StartCoroutine ("PhaseOneProjectile");
				} else {
					StartCoroutine ("PhaseOneMelee");
				}
			} else if (phase == 2) {
				if (canCharge)
					StartCoroutine ("PhaseTwoCharge");
				else if (canMelee)
					StartCoroutine ("PhaseOneMelee");
			}
		}
	}

	void OnTriggerStay2D(Collider2D other)
	{
		if (other.gameObject.tag == "PlayerMelee" && Time.time - lastHit >= 0.25f) {
			health--;
			if (DataHolderController.meleeUpgrade == true) {
				health--; //if the powerup is held, does double damage
			}
			lastHit = Time.time;
		}
	}

	void OnCollisionEnter2D(Collision2D other)
	{
		if (other.gameObject.tag == "Bullet" && !stunned) {
			StartCoroutine("Stun");
		}
	}


	IEnumerator PhaseOneProjectile()
	{
		if (phase == 1 && canFire && !stunned) {
			canFire = false;
			//if (Vector2.Distance (player.position, gameObject.transform.position) > 5.0f) {
				for (int i = 0; i < 10; i++) {
					Transform newProjectile = Instantiate (projectile, gameObject.transform.position + offset, Quaternion.identity) as Transform;
					SE.BossProjectile();
					yield return new WaitForSeconds (0.3f);
				}
				yield return new WaitForSeconds (2);
				canFire = true;
			//} 
		}
	}

	IEnumerator PhaseOneMelee()
	{
		if (phase == 2 && canMelee && !stunned){
			//place holder before melee animation implementation
			canMelee = false;
			animator.Play("BossSecondPrepare", -1, 0f);
			yield return new WaitForSeconds (1);
			melee.SetActive (true);
			animator.Play("BossSecondAttack", -1, 0f);
			SE.HopperLand();
			yield return new WaitForSeconds (0.5f);
			melee.SetActive (false);
			yield return new WaitForSeconds (2);
			canMelee = true;
		}
	}

	IEnumerator PhaseTwoCharge()
	{
		if (phase == 2 && canCharge && !stunned) {
			SE.BossRoar();
			canCharge = false;
			if (!facingRight) {
				rb2d.velocity = new Vector2 (1f, 0);
				yield return new WaitForSeconds (0.5f);
				charge.SetActive (true);
				rb2d.velocity = new Vector2 (-10f, 0);
				yield return new WaitForSeconds (1.55f);
				charge.SetActive (false);
				rb2d.velocity = new Vector2 (0, 0);
			} 
			else {
				rb2d.velocity = new Vector2 (-1f, 0);
				yield return new WaitForSeconds (0.5f);
				charge.SetActive (true);
				rb2d.velocity = new Vector2 (10f, 0);
				yield return new WaitForSeconds (1.55f);
				charge.SetActive (false);
				rb2d.velocity = new Vector2 (0, 0);
			}

			yield return new WaitForSeconds (5f);
			facingRight = !facingRight;
			Vector3 theScale = transform.localScale;
			theScale.x *= -1;
			transform.localScale = theScale;

			yield return new WaitForSeconds (2f);
			canCharge = true;
		}
	}

	IEnumerator Stun()
	{
		stunned = true;
		if (DataHolderController.gunUpgrade == true) {
			yield return new WaitForSeconds (2.5f);
			stunned = false;
		} 
		else {
			yield return new WaitForSeconds (1.5f);
			stunned = false;
		}
	}
}
