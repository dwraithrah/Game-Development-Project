﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossProjectileController : MonoBehaviour {

	private Vector2 angle;
	private bool moveLeft;
	private Rigidbody2D rb2d;

	private GameObject soundEffects;
    private SoundEffects SE;

	public BossProjectileController(bool left)
	{
		moveLeft = left;
	}

	// Use this for initialization
	void Start () {
		rb2d = gameObject.GetComponent<Rigidbody2D> ();

		generateAngle ();
		rb2d.AddForce (angle);

		soundEffects = GameObject.Find("SoundEffectsController");
        SE = (SoundEffects)soundEffects.GetComponent(typeof(SoundEffects));
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void generateAngle()
	{
		angle = new Vector2(Random.Range(-1000f, -50f), Random.Range(300f, 800f));
	}

	void OnCollisionEnter2D(Collision2D other)
	{
		if (other.gameObject.tag == "Bullet") {
			other.gameObject.SetActive (false);
			gameObject.SetActive (false);
			SE.HopperLand();
		} 
		else if (other.gameObject.tag == "Player") {
			gameObject.SetActive (false);
			SE.HopperLand();
			//DataHolderController.playerHealth -= 0.5f;
		}
		else if (other.gameObject.tag != "Enemy" && other.gameObject.tag != "BossProjectile") {
			gameObject.SetActive (false);
			SE.HopperLand();
		} 
	}
}
