﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoolController : MonoBehaviour {

	Animator animator;

	void Start () {
		animator = GetComponent<Animator>();
		animator.Play("Pool", -1, 0f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
