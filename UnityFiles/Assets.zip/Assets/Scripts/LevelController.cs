﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class LevelController: MonoBehaviour {
  public SortedList<int, Entity> entities = new SortedList<int,Entity>(32);
  private List<Entity> spawned = new List<Entity>(32), 
                       destroyed = new List<Entity>(32);
  public BackgroundManager bg;

  public void Start() {
    bg = GameObject.Find("BackgroundManager").GetComponent<BackgroundManager>();
  }

  public void FixedUpdate() {
    for(int i = 0, n = entities.Count; i < n; i++) {
      entities[i].ManualUpdate();
    }
    
  }


}
