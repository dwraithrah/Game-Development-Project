﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class IntroController : MonoBehaviour {

    public GameObject dialogBox;
    public Text dialogText;
    public string[] dialogue;
    private int storyPlace = 0;

    // Use this for initialization
    void Start () {

        //on start the dialog box is active and visible 
        dialogBox.SetActive(true);
        dialogue = new string[3];
        PopulateArray();
        IntroStory(dialogue[storyPlace]);

    }
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown(KeyCode.Escape))//if player hits escape button, skip to tutorial
        {
            SceneManager.LoadScene(2);//load tutorial
        }
        else if(Input.GetKeyDown(KeyCode.Space) && storyPlace != dialogue.Length -1)//if player hits space and we haven't reached end of dialogue, load next set of text
        {
            storyPlace++;  //increase array index
            IntroStory(dialogue[storyPlace]);  //display next bit of story
        }
        else if(Input.GetKeyDown(KeyCode.Space) && storyPlace == dialogue.Length -1) //if player hits space and we're at the end, load tutorial
        {
            SceneManager.LoadScene(2);
        }

	}

    public void PopulateArray()
    {

        dialogue[0] = "It was a time of economic despair for scavengers across the known sectors of space.  " +
                      "Due to an unprecedented time of peace, finding salvage from wrecked ships, satellites and space stations was becoming increasingy rare and the competition increasingly fierce.  " +
                      "This led various scavenger groups to begin exploring beyond the known reaches to see if remnants from long-forgotten exploration and colonization ships could be found.  " +
                      "The crew of the S.S. Zephyr also decided to take this risk in hope of profits.";
        dialogue[1] = "After a weeks' long trip into uncharted territory they came upon what seemed to be an intact but abandoned space station orbiting an onyx moon.  " +
                      "Initial excitement turned to divided opinion as to whether to enter the space station and explore.  " +
                      "Various members were wary and wondered who had created the station and why it was abandoned.  " +
                      "The majority simply saw the potential for high profits to be gained from salvaging the station.";
        dialogue[2] = "Ianella, a talented salvager and explorer, was more interested in the chance to explore this station to learn more about it.  " +
                      "Impatience taking over her, while the rest of the crew debated their options, she slipped into a space suit and flew to the space station before she could be stopped.  " +
                      "She easily found an entrance into the station's docking bay and warehouse. After making her way into the station, she barely had time to make note of her surroundings when" +
                      " the captain of the Zephyr, Borst, contacted her." +
                      "And so the story begins-";


    }

    public void IntroStory(string dialog)
    {
        dialogText.text = dialog;

    }
}
