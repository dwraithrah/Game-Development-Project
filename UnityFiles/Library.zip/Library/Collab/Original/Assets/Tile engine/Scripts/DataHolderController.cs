﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//There's a tutorial for switching scenes and keeping objects for those scenes.
//https://www.youtube.com/watch?annotation_id=annotation_3968548225&feature=iv&src_vid=S9h_iu4Zx5I&v=i2W5O5qxCuo
//Highly recommend everyone looks at this.

public class DataHolderController : MonoBehaviour {

    public static int holdScore;
    public static int playerHealth;
    public static int sceneIndex;
    public static DataHolderController anymanager;

    bool gameStart;  //this is to ensure that the initial load is done only once

    void Awake()
    {
        //if (!gameStart)
        //{
            //initial values at game start
           // holdScore = 0;
            playerHealth = 5;
			sceneIndex =  SceneManager.GetActiveScene().buildIndex;
            Debug.Log(sceneIndex);

            anymanager = this;

            //load next scene (start of game) while keeping this object, the data holder.
            //Async means scene is loaded in background
            //SceneManager.LoadSceneAsync(sceneIndex, LoadSceneMode.Additive);

            gameStart = true;

            //sceneIndex++;
            //Debug.Log(sceneIndex);
            //SceneManager.LoadSceneAsync(sceneIndex, LoadSceneMode.Additive);


        //}
        
    }
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {

        if(playerHealth <= 1)
        {
            StartCoroutine(ReloadScene());
			playerHealth = 5;
        }
	}

    IEnumerator ReloadScene()
    {
        SceneManager.LoadSceneAsync(DataHolderController.sceneIndex, LoadSceneMode.Additive);
        yield return null;
        Debug.Log("Unloading Scene");
        Debug.Log(sceneIndex);
        SceneManager.UnloadSceneAsync(DataHolderController.sceneIndex);
        

    }

    //function to unload scenes
    public void UnloadScene(int scene)
    {
        StartCoroutine(Unload(scene));
    }

    IEnumerator Unload(int scene)
    {

        SceneManager.LoadSceneAsync(scene, LoadSceneMode.Additive);
        yield return null;
        SceneManager.UnloadScene(scene-1);
    }
}
