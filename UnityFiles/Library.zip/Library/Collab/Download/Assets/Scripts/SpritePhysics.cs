﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class SpritePhysics: MonoBehaviour
{
  private BoxCollider2D collider;
  private Bounds bounds;
  private BgMap foregroundTiles;
  private byte[] tileCollision;

  public Vector2 velocity;
  public Vector2 position;
  public float friction;       // Friction in the X direction
  public float gravity;        // Gravity in the Y direction
  public float fallSpeedLimit; // Terminal falling speed

  public bool onGround = false;
  public bool applyFriction = false;
  public bool applyGravity = true;
  public bool applyTileCollision = true;


  public void Start() {
    collider = GetComponent<BoxCollider2D>();
    foregroundTiles = GameObject.Find("Background Manager").GetComponent<BackgroundManager>().layers[2];
    tileCollision = TilesetManager.GetTileCollision(foregroundTiles.tileset);
  }

  public void FixedUpdate() {
    bounds = collider.bounds;
    if(applyFriction) {
      if(Math.Abs(velocity.x) > friction)
        if(velocity.x > 0)
          velocity.x -= friction;
        else
          velocity.x += friction;
      else
        velocity.x = 0;
    }
    if(applyTileCollision) ApplyTileCollisionX(bounds);
    position.x += velocity.x;
    bounds.center += new Vector3(velocity.x, 0, 0);


    if(applyTileCollision) ApplyTileCollisionY(bounds);
    if(applyGravity && !onGround) {
      if(velocity.y < fallSpeedLimit) velocity.y = fallSpeedLimit;
      else velocity.y -= gravity;
    } 
    position.y += velocity.y;
    bounds.center += new Vector3(0, velocity.y, 0);

    transform.localPosition = position;
  }

  public void ApplyAcceleration(Vector2 delta, Vector2 limit) {
    Vector2 direction = new Vector2(Math.Sign(limit.x - velocity.x),
                                    Math.Sign(limit.y - velocity.y));
    velocity += delta;
    if(Math.Sign(limit.x - velocity.x) != direction.x)
      velocity.x = limit.x;
    if(Math.Sign(limit.y - velocity.y) != direction.y)
      velocity.y = limit.y;
  }

  private void ApplyTileCollisionX(Bounds b) {
    int txOldEdge; // x tile coordinate of forward edge, before
    int txNewEdge; // x tile coordinate of forward edge, after
    int tyMin, tyMax; // y tile coordinates of top & bottom edges
    float xEdgeInTile; // x coordinate offset within tile of forward edge

    tyMin = (int) Math.Floor(b.min.y);
    tyMax = (int) Math.Floor(b.max.y);
    if(velocity.x < 0) { // moving left
      txOldEdge = (int) Math.Floor(b.min.x);
      txNewEdge = (int) Math.Floor(b.min.x + velocity.x);
      xEdgeInTile = b.min.x - txOldEdge;
      for(int tx = txOldEdge; tx >= txNewEdge; tx--) {
        for(int ty = tyMax; ty >= tyMin; ty--) {
          ushort tile = foregroundTiles[tx, ty];
          if(tile == 0xFFFF) continue;
          switch(tileCollision[tile]) {
            case (byte) 'e': // Solid
            case (byte) 'c': // left wall
              if(ty == tyMin) // allow climbing of one-tile-high steps
                position.y += 1 - (b.min.y - tyMin);
              else {
                position.x += (tx - txOldEdge) + (1 - xEdgeInTile); // align left edge of bounding box to right edge of tile
                velocity.x = 0;
              } 
              return;
          } 
        }
      }
    }
    else if(velocity.x > 0) { // moving right
      txOldEdge = (int) Math.Floor(b.max.x);
      txNewEdge = (int) Math.Floor(b.max.x + velocity.x);
      xEdgeInTile = b.max.x - txOldEdge;
      for(int tx = txOldEdge; tx <= txNewEdge; tx++) {
        for(int ty = tyMax; ty >= tyMin; ty--) {
          ushort tile = foregroundTiles[tx, ty];
          if(tile == 0xFFFF) continue;
          switch(tileCollision[tile]) {
            case (byte) 'e': // solid
            case (byte) 'b': // right wall
              if(ty == tyMin) // allow climbing of one-tile-high steps
                position.y += 1 - (b.min.y - tyMin);  
              else
                position.x += (tx - txOldEdge) - xEdgeInTile; // align right edge of bounding box to left edge of tile
                velocity.x = 0;
              return;
          }
        }
      }
    }
  }

  private void ApplyTileCollisionY(Bounds b) {
    int tyOldEdge, tyNewEdge;
    int txMin, txMax;
    float yEdgeInTile;

    txMin = (int) Math.Floor(b.min.x);
    txMax = (int) Math.Floor(b.max.x);
    if(velocity.y > 0) { // moving up
      tyOldEdge = (int) Math.Floor(b.max.y);
      tyNewEdge = (int) Math.Floor(b.max.y + velocity.y);
      yEdgeInTile = b.max.y - tyOldEdge;

      for(int ty = tyOldEdge; ty <= tyNewEdge; ty++) {
        for(int tx = txMin; tx <= txMax; tx++) {
          ushort tile = foregroundTiles[tx, ty];
          if(tile == 0xFFFF) continue;
          switch(tileCollision[tile]) {
            case (byte) 'd': // ceiling
            case (byte) 'e': // solid 
              position.y += (ty - tyOldEdge) - yEdgeInTile; // align top edge to bottom of tile
              velocity.y = -1f/16;
              return;
          }
        }
      }
    }
    else if(velocity.y < 0) { // moving down
      tyOldEdge = (int) Math.Floor(b.min.y);
      tyNewEdge = (int) Math.Floor(b.min.y + velocity.y);
      yEdgeInTile = b.min.y - tyOldEdge;
       
      for(int ty = tyOldEdge; ty >= tyNewEdge; ty--) {
        for(int tx = txMin; tx <= txMax; tx++) {
          ushort tile = foregroundTiles[tx, ty];
          if(tile == 0xFFFF) continue;
          switch(tileCollision[tile]) {
            case (byte) 'a': // floor
            case (byte) 'e': // solid
              position.y += (ty - tyOldEdge) + (1 - yEdgeInTile); // align bottom edge to top of tile
              velocity.y = 0;
              onGround = true;                                   // also, set the grounded flag here
              return;
          }
        }
      }
    }
  }
}
