﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class SpritePhysics: MonoBehaviour
{
  public BoxCollider2D collider;
  private BgMap foregroundTiles;

  public Vector2 velocity;
  public Vector2 gravity;

  public bool onGround;

  public void Awake() {
    collider = GetComponent<BoxCollider2D>();
    foregroundTiles = GameObject.Find("Background Manager").GetComponent<BackgroundManager>().layers[2];
  }

  public void FixedUpdate() {
    // TODO: tilemap collision
  } 
}
